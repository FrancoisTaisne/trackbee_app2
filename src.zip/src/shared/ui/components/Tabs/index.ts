export {
  Tabs,
  TabsList,
  TabsTrigger,
  TabsContent
} from './Tabs'