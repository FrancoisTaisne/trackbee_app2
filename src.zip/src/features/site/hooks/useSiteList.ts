/**
 * useSiteList Hook - Gestion de la liste des sites
 * Interface pour lister, filtrer, créer et supprimer des sites
 * REFACTORED: Utilise désormais useHydrate pour une approche centralisée
 */

import { useCallback, useMemo } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { useEventBus } from '@/core/orchestrator/EventBus'
import { useHydrate } from '@/core/hooks/useHydrate'
import { httpClient } from '@/core/services/api/HttpClient'
import { logger } from '@/core/utils/logger'
import type { AppError } from '@/core/types/common'
import type { Site, Installation, Machine } from '@/core/types'
import { siteQueryKeys } from './useSite'

// ==================== TYPES ====================

interface SiteBundle {
  site: Site
  installations: Installation[]
  machines: Machine[]
  installationCount: number
  machineCount: number
}

interface CreateSiteData {
  name: string
  description?: string
  address?: string
  lat?: number
  lng?: number
  altitude?: number
  isPublic?: boolean
  tags?: string[]
}

interface UpdateSiteData {
  name?: string
  description?: string
  address?: string
  lat?: number
  lng?: number
  altitude?: number
  isPublic?: boolean
  tags?: string[]
}

interface SiteFilters {
  search?: string
  ownership?: 'owned' | 'shared' | 'all'
  hasInstallations?: boolean
  isPublic?: boolean
  coordinateSystem?: string
  tags?: string[]
}

interface SiteSorting {
  field: 'name' | 'createdAt' | 'updatedAt' | 'installationCount'
  order: 'asc' | 'desc'
}

interface UseSiteListReturn {
  sites: SiteBundle[]
  isLoading: boolean
  error: Error | null
  refetch: () => Promise<void>
  createSite: (data: CreateSiteData) => Promise<Site>
  updateSite: (id: number, data: UpdateSiteData) => Promise<Site>
  deleteSite: (id: number) => Promise<void>
  geocodeAddress: (address: string) => Promise<GeocodeResult[]>
}

interface GeocodeResult {
  lat: number
  lng: number
  formattedAddress: string
}

type SiteError = 'SITE_NOT_FOUND' | 'SITE_CREATE_FAILED' | 'SITE_UPDATE_FAILED' | 'PERMISSION_DENIED'

// ==================== LOGGER SETUP ====================

const siteListLog = {
  trace: (msg: string, data?: unknown) => logger.trace('siteList', msg, data),
  debug: (msg: string, data?: unknown) => logger.debug('siteList', msg, data),
  info: (msg: string, data?: unknown) => logger.info('siteList', msg, data),
  warn: (msg: string, data?: unknown) => logger.warn('siteList', msg, data),
  error: (msg: string, data?: unknown) => logger.error('siteList', msg, data)
}

// ==================== API FUNCTIONS ====================

/**
 * Récupère tous les sites avec leurs relations - Backend First Strategy
 */
const _fetchSiteBundles = async (filters?: SiteFilters): Promise<SiteBundle[]> => {
  siteListLog.debug('🔄 Fetching site bundles - Backend First Strategy...', { filters })

  // ÉTAPE 1: Essayer d'abord le backend (source de vérité)
  try {
    siteListLog.debug('🌐 Attempting backend fetch first...')

    // Construire les paramètres de requête
    const params = new URLSearchParams()
    if (filters?.search) params.append('search', filters.search)
    if (filters?.ownership) params.append('ownership', filters.ownership)
    if (filters?.hasInstallations !== undefined) params.append('hasInstallations', String(filters.hasInstallations))
    if (filters?.isPublic !== undefined) params.append('isPublic', String(filters.isPublic))
    if (filters?.coordinateSystem) params.append('coordinateSystem', filters.coordinateSystem)

    // Récupérer les données du backend avec les vraies routes
    const [sites, installations, machines] = await Promise.all([
      httpClient.get<Site[]>(`/api/site?${params}`),
      // Note: pas de route installations globale dans le backend, sera récupéré au niveau machine/site
      Promise.resolve([]),
      httpClient.get<Machine[]>('/api/machine/allByMod').catch(() =>
        httpClient.get<Machine[]>('/api/machine/all').catch(() => [])
      )
    ])

    siteListLog.info('✅ Backend data fetched successfully', {
      sites: sites.length,
      installations: installations.length,
      machines: machines.length
    })

    // Construire les bundles depuis les données backend
    const backendBundles: SiteBundle[] = sites.map(site => {
      const siteInstallations = installations.filter(inst => inst.siteId === site.id)
      const siteMachines = siteInstallations
        .map(inst => machines.find(machine => machine.id === inst.machineId))
        .filter(Boolean)

      return {
        site: {
          id: site.id,
          name: site.name,
          description: site.description || '',
          coordinates: site.lat && site.lng ? { latitude: site.lat, longitude: site.lng } : undefined,
          address: site.address || '',
          isActive: true,
          createdAt: new Date(site.createdAt || Date.now()),
          updatedAt: new Date(site.updatedAt || Date.now()),
          lat: site.lat,
          lng: site.lng || site.lon
        },
        installations: siteInstallations.map(inst => ({
          id: inst.id,
          machineId: inst.machineId,
          siteId: inst.siteId,
          isActive: inst.isActive,
          installedAt: new Date(inst.createdAt || Date.now())
        })),
        machines: siteMachines.map(machine => ({
          id: machine.id,
          name: machine.name,
          macAddress: machine.macAddress,
          model: machine.model,
          connected: machine.lastConnectionState === 'connected'
        })),
        campaigns: [], // TODO: Récupérer campaigns depuis backend
        calculations: [], // TODO: Récupérer calculations depuis backend
        statistics: {
          totalInstallations: siteInstallations.length,
          activeInstallations: siteInstallations.filter(i => i.isActive).length,
          totalMachines: siteMachines.length,
          connectedMachines: siteMachines.filter(m => m.lastConnectionState === 'connected').length,
          totalCampaigns: 0,
          activeCampaigns: 0,
          completedCalculations: 0,
          failedCalculations: 0,
          lastActivity: undefined
        }
      }
    })

    // 🎯 HYDRATATION AUTOMATIQUE - Synchroniser avec IndexedDB
    try {
      siteListLog.debug('💾 Hydrating IndexedDB with backend data...')
      await hydrateIndexedDBWithBackendData(sites, installations, machines)
      siteListLog.info('✅ IndexedDB hydrated successfully with backend data')
    } catch (hydrationError) {
      siteListLog.warn('⚠️ Failed to hydrate IndexedDB', { hydrationError })
    }

    return backendBundles

  } catch (backendError) {
    siteListLog.warn('⚠️ Backend fetch failed, falling back to IndexedDB...', { backendError })

    // ÉTAPE 2: Fallback vers IndexedDB si backend échoue
    try {
      const { DataService } = await import('@/core/services/data/DataService')
      const bundles = await DataService.buildSiteBundles()

      const siteBundles: SiteBundle[] = bundles.map(bundle => ({
        site: {
          id: bundle.id,
          name: bundle.name,
          description: bundle.description || '',
          coordinates: bundle.coordinates,
          address: bundle.address || '',
          isActive: true,
          createdAt: new Date(),
          updatedAt: new Date(),
          lat: bundle.coordinates?.latitude,
          lng: bundle.coordinates?.longitude
        },
        installations: bundle.installations || [],
        machines: bundle.machines || [],
        campaigns: [],
        calculations: [],
        statistics: bundle.statistics || {
          totalInstallations: 0,
          activeInstallations: 0,
          totalMachines: 0,
          connectedMachines: 0,
          totalCampaigns: 0,
          activeCampaigns: 0,
          completedCalculations: 0,
          failedCalculations: 0,
          lastActivity: undefined
        }
      }))

      // Appliquer les filtres côté client
      let filteredBundles = siteBundles
      if (filters?.search) {
        const searchLower = filters.search.toLowerCase()
        filteredBundles = filteredBundles.filter(bundle =>
          bundle.site.name.toLowerCase().includes(searchLower) ||
          bundle.site.description?.toLowerCase().includes(searchLower) ||
          bundle.site.address?.toLowerCase().includes(searchLower)
        )
      }

      siteListLog.info('✅ Site bundles fetched from IndexedDB fallback', { count: filteredBundles.length })
      return filteredBundles

    } catch (indexedError) {
      siteListLog.error('❌ Both backend and IndexedDB failed', { backendError, indexedError })
      return []
    }
  }
}

/**
 * Hydratation automatique d'IndexedDB avec les données backend
 */
const hydrateIndexedDBWithBackendData = async (
  sites: Site[],
  installations: Installation[],
  machines: Machine[]
): Promise<void> => {
  try {
    const { database } = await import('@/core/database/schema')

    // Hydratation des sites
    await Promise.all(sites.map(site =>
      database.sites.put({
        id: String(site.id),
        name: site.name,
        description: site.description || '',
        address: site.address || '',
        lat: site.lat || undefined,
        lng: site.lng || site.lon || undefined,
        altitude: site.altitude || undefined,
        isActive: true,
        createdAt: new Date(site.createdAt || Date.now()),
        updatedAt: new Date(site.updatedAt || Date.now()),
        syncedAt: new Date()
      })
    ))

    // Hydratation des machines
    await Promise.all(machines.map(machine =>
      database.machines.put({
        id: String(machine.id),
        name: machine.name || '',
        macAddress: machine.macAddress || '',
        model: machine.model || '',
        lastConnectionState: machine.lastConnectionState || 'disconnected',
        lastSeenAt: machine.lastSeenAt ? new Date(machine.lastSeenAt) : undefined,
        createdAt: new Date(machine.createdAt || Date.now()),
        updatedAt: new Date(machine.updatedAt || Date.now()),
        syncedAt: new Date()
      })
    ))

    // Hydratation des installations
    await Promise.all(installations.map(installation =>
      database.installations.put({
        id: String(installation.id),
        machineId: String(installation.machineId),
        siteId: String(installation.siteId),
        isActive: installation.isActive ? 1 : 0,
        createdAt: new Date(installation.createdAt || Date.now()),
        updatedAt: new Date(installation.updatedAt || Date.now()),
        syncedAt: new Date()
      })
    ))

    // Marquer la dernière synchronisation
    await database.setAppState('lastDataSync', new Date())

    siteListLog.debug('💾 IndexedDB hydration completed', {
      sites: sites.length,
      machines: machines.length,
      installations: installations.length
    })

  } catch (error) {
    siteListLog.error('❌ IndexedDB hydration failed', { error })
    throw error
  }
}

/**
 * Crée un nouveau site
 */
const createSite = async (data: CreateSiteData): Promise<Site> => {
  siteListLog.debug('Creating site', { data })

  // Valider les données avant envoi
  if (!data.name.trim()) {
    throw new AppError('Le nom du site est obligatoire', 'VALIDATION_ERROR')
  }

  if (data.lat && (data.lat < -90 || data.lat > 90)) {
    throw new AppError('Latitude invalide', 'VALIDATION_ERROR')
  }

  if (data.lng && (data.lng < -180 || data.lng > 180)) {
    throw new AppError('Longitude invalide', 'VALIDATION_ERROR')
  }

  const response = await httpClient.post<Site>('/api/site', {
    name: data.name.trim(),
    description: data.description?.trim(),
    address: data.address?.trim(),
    lat: data.lat,
    lng: data.lng,
    altitude: data.altitude,
    coordinateSystem: data.coordinateSystem,
    isPublic: data.isPublic ?? false,
    metadata: data.metadata
  })
  const site = response.data!

  siteListLog.info('Site created successfully', { site })
  return site
}

/**
 * Met à jour un site
 */
const updateSite = async (id: number, data: UpdateSiteData): Promise<Site> => {
  siteListLog.debug('Updating site', { id, data })

  const response = await httpClient.put<Site>(`/api/site/${id}`, data)
  const site = response.data!

  siteListLog.info('Site updated successfully', { site })
  return site
}

/**
 * Supprime un site
 */
const deleteSite = async (id: number): Promise<void> => {
  siteListLog.debug('Deleting site', { id })

  // Vérifier si le site peut être supprimé
  const response = await httpClient.get<Installation[]>(`/api/site/${id}/installations`)
  const installations = response.data!
  if (installations.length > 0) {
    throw new AppError(
      'Impossible de supprimer un site avec des installations. Retirez d\'abord tous les devices.',
      'CONSTRAINT_VIOLATION'
    )
  }

  await httpClient.delete(`/api/site/${id}`)

  siteListLog.info('Site deleted successfully', { id })
}

/**
 * Géocode une adresse
 */
interface GeocodeResult {
  lat: number
  lng: number
  formattedAddress: string
  components?: Record<string, string>
}

const geocodeAddress = async (address: string): Promise<GeocodeResult[]> => {
  siteListLog.debug('Geocoding address', { address })

  if (!address.trim()) {
    return []
  }

  try {
    const response = await httpClient.get<GeocodeResult[]>(`/api/geocode?address=${encodeURIComponent(address)}`)
    const results = response.data!

    siteListLog.debug('Address geocoded successfully', {
      address,
      resultCount: results.length
    })

    return results
  } catch (error) {
    siteListLog.error('Geocoding failed', { address, error })
    throw new AppError('Échec du géocodage de l\'adresse', 'GEOCODING_FAILED')
  }
}

/**
 * Calcule la distance entre deux positions
 */
const calculateDistance = (
  lat1: number, lng1: number,
  lat2: number, lng2: number
): number => {
  const R = 6371 // Rayon de la Terre en km
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLng = (lng2 - lng1) * Math.PI / 180
  const a = Math.sin(dLat/2) * Math.sin(dLat/2) +
            Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
            Math.sin(dLng/2) * Math.sin(dLng/2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))
  return R * c
}

// ==================== SITE ERROR HELPER ====================

const createSiteError = (type: SiteError, originalError?: Error): AppError => {
  const SiteErrorMessages: Record<SiteError, string> = {
    SITE_NOT_FOUND: 'Site not found',
    SITE_CREATE_FAILED: 'Failed to create site',
    SITE_UPDATE_FAILED: 'Failed to update site',
    PERMISSION_DENIED: 'Permission denied'
  }
  return new AppError(
    SiteErrorMessages[type],
    type,
    'SITE',
    originalError
  )
}

// ==================== MAIN HOOK ====================

/**
 * Hook pour la gestion de la liste des sites
 * REFACTORED: Utilise useHydrateSites pour récupérer les données via /api/me/hydrate
 */
export const useSiteList = (
  filters?: SiteFilters,
  sorting?: SiteSorting
): UseSiteListReturn => {
  const queryClient = useQueryClient()
  const eventBus = useEventBus()

  // ==================== USE HYDRATE DATA ====================

  const { sites: hydratedSites, machines, isLoading: hydrateLoading, error: hydrateError, refetch } = useHydrate()

  // Construire les bundles depuis les données hydratées
  const rawSites = useMemo(() => {
    if (!hydratedSites || !machines) return []

    siteListLog.debug('🎯 Building site bundles from hydrated data', {
      sites: hydratedSites.length,
      machines: machines.length
    })

    const bundles: SiteBundle[] = hydratedSites.map(site => {
      // Trouver les machines associées au site
      const siteMachines = machines.filter(m => m.installation?.siteId === site.id)

      return {
        site: {
          id: site.id,
          name: site.name,
          description: site.description || '',
          coordinates: site.lat && site.lng ? { latitude: site.lat, longitude: site.lng } : undefined,
          address: site.address || '',
          isActive: true,
          createdAt: new Date(site.createdAt || Date.now()),
          updatedAt: new Date(site.updatedAt || Date.now()),
          lat: site.lat,
          lng: site.lng
        },
        installations: siteMachines.map(m => m.installation).filter(Boolean),
        machines: siteMachines.map(machine => ({
          id: machine.id,
          name: machine.name,
          macAddress: machine.macAddress,
          model: machine.model,
          connected: false
        })),
        campaigns: [],
        calculations: [],
        statistics: {
          totalInstallations: siteMachines.length,
          activeInstallations: siteMachines.filter(m => m.isActive).length,
          totalMachines: siteMachines.length,
          connectedMachines: 0,
          totalCampaigns: 0,
          activeCampaigns: 0,
          completedCalculations: 0,
          failedCalculations: 0,
          lastActivity: undefined
        }
      }
    })

    siteListLog.info('✅ Site bundles built from hydrated data', { count: bundles.length })
    return bundles
  }, [hydratedSites, machines])

  const isLoading = hydrateLoading
  const queryError = hydrateError

  // ==================== FILTERED & SORTED SITES ====================

  const sites = useMemo(() => {
    let filtered = [...rawSites]

    // Appliquer les filtres client-side pour performance
    if (filters?.bounds) {
      filtered = filtered.filter(bundle => {
        const { site } = bundle
        if (!site.lat || !site.lng) return false

        const { bounds } = filters
        return (
          site.lat >= bounds.south &&
          site.lat <= bounds.north &&
          site.lng >= bounds.west &&
          site.lng <= bounds.east
        )
      })
    }

    // Appliquer le tri
    if (sorting) {
      filtered.sort((a, b) => {
        let comparison = 0

        switch (sorting.field) {
          case 'name':
            comparison = a.site.name.localeCompare(b.site.name)
            break

          case 'createdAt':
            comparison = new Date(a.site.createdAt).getTime() - new Date(b.site.createdAt).getTime()
            break

          case 'updatedAt':
            comparison = new Date(a.site.updatedAt).getTime() - new Date(b.site.updatedAt).getTime()
            break

          case 'installationCount':
            comparison = a.statistics.totalInstallations - b.statistics.totalInstallations
            break

          case 'distance':
            if (sorting.userPosition && a.site.lat && a.site.lng && b.site.lat && b.site.lng) {
              const distA = calculateDistance(
                sorting.userPosition.lat, sorting.userPosition.lng,
                a.site.lat, a.site.lng
              )
              const distB = calculateDistance(
                sorting.userPosition.lat, sorting.userPosition.lng,
                b.site.lat, b.site.lng
              )
              comparison = distA - distB
            }
            break

          default:
            comparison = a.site.name.localeCompare(b.site.name)
        }

        return sorting.direction === 'desc' ? -comparison : comparison
      })
    } else {
      // Tri par défaut : par nom
      filtered.sort((a, b) => a.site.name.localeCompare(b.site.name))
    }

    siteListLog.debug('Sites filtered and sorted', {
      total: rawSites.length,
      filtered: filtered.length,
      filters,
      sorting
    })

    return filtered
  }, [rawSites, filters, sorting])

  // ==================== MUTATIONS ====================

  const createSiteMutation = useMutation({
    mutationFn: createSite,
    onSuccess: async (newSite) => {
      // Invalider les caches
      queryClient.invalidateQueries({ queryKey: siteQueryKeys.lists() })

      // 🎯 HYDRATATION AUTOMATIQUE - Ajouter le nouveau site à IndexedDB
      try {
        const { database } = await import('@/core/database/schema')
        await database.sites.put({
          id: newSite.id,
          name: newSite.name,
          description: newSite.description || '',
          address: newSite.address || '',
          lat: newSite.lat || undefined,
          lng: newSite.lng || newSite.lon || undefined,
          altitude: newSite.altitude || undefined,
          isActive: true,
          createdAt: new Date(),
          updatedAt: new Date(),
          syncedAt: new Date()
        })

        siteListLog.info('✅ New site automatically hydrated to IndexedDB', {
          siteId: newSite.id,
          siteName: newSite.name
        })
      } catch (hydrationError) {
        siteListLog.warn('⚠️ Failed to hydrate new site to IndexedDB', {
          error: hydrationError,
          site: newSite
        })
      }

      // Événement global
      eventBus.emit('site:created', { site: newSite })

      siteListLog.info('Site created and caches updated', { site: newSite })
    },
    onError: (error) => {
      siteListLog.error('Site creation failed', error)
      throw createSiteError('SITE_ALREADY_EXISTS', error as Error)
    }
  })

  const updateSiteMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: UpdateSiteData }) =>
      updateSite(id, data),
    onSuccess: async (updatedSite) => {
      // Invalider les caches spécifiques
      queryClient.invalidateQueries({ queryKey: siteQueryKeys.lists() })
      queryClient.invalidateQueries({ queryKey: siteQueryKeys.detail(updatedSite.id) })
      queryClient.invalidateQueries({ queryKey: siteQueryKeys.bundle(updatedSite.id) })

      // 🎯 HYDRATATION AUTOMATIQUE - Mettre à jour le site dans IndexedDB
      try {
        const { database } = await import('@/core/database/schema')
        await database.sites.update(updatedSite.id, {
          name: updatedSite.name,
          description: updatedSite.description || '',
          address: updatedSite.address || '',
          lat: updatedSite.lat || undefined,
          lng: updatedSite.lng || updatedSite.lon || undefined,
          altitude: updatedSite.altitude || undefined,
          updatedAt: new Date(),
          syncedAt: new Date()
        })

        siteListLog.info('✅ Updated site automatically synced to IndexedDB', {
          siteId: updatedSite.id,
          siteName: updatedSite.name
        })
      } catch (hydrationError) {
        siteListLog.warn('⚠️ Failed to sync updated site to IndexedDB', {
          error: hydrationError,
          site: updatedSite
        })
      }

      // Événement global
      eventBus.emit('site:updated', { siteId: updatedSite.id, site: updatedSite })

      siteListLog.info('Site updated and caches invalidated', { site: updatedSite })
    },
    onError: (error) => {
      siteListLog.error('Site update failed', error)
      throw createSiteError('SITE_NOT_FOUND', error as Error)
    }
  })

  const deleteSiteMutation = useMutation({
    mutationFn: deleteSite,
    onSuccess: async (_, deletedId) => {
      // Invalider les caches
      queryClient.invalidateQueries({ queryKey: siteQueryKeys.lists() })
      queryClient.removeQueries({ queryKey: siteQueryKeys.detail(deletedId) })
      queryClient.removeQueries({ queryKey: siteQueryKeys.bundle(deletedId) })

      // 🎯 HYDRATATION AUTOMATIQUE - Supprimer le site d'IndexedDB
      try {
        const { database } = await import('@/core/database/schema')
        await database.sites.delete(deletedId)

        siteListLog.info('✅ Deleted site automatically removed from IndexedDB', {
          siteId: deletedId
        })
      } catch (hydrationError) {
        siteListLog.warn('⚠️ Failed to remove deleted site from IndexedDB', {
          error: hydrationError,
          siteId: deletedId
        })
      }

      // Événement global
      eventBus.emit('site:deleted', { siteId: deletedId })

      siteListLog.info('Site deleted and cleaned up', { siteId: deletedId })
    },
    onError: (error) => {
      siteListLog.error('Site deletion failed', error)
      throw createSiteError('SITE_HAS_INSTALLATIONS', error as Error)
    }
  })

  // ==================== GEOCODING ====================

  const geocodeMutation = useMutation({
    mutationFn: geocodeAddress,
    onError: (error) => {
      siteListLog.error('Geocoding failed', error)
      throw createSiteError('GEOCODING_FAILED', error as Error)
    }
  })

  // ==================== HELPER FUNCTIONS ====================

  const createSiteHandler = useCallback((data: CreateSiteData) => {
    return createSiteMutation.mutateAsync(data)
  }, [createSiteMutation])

  const updateSiteHandler = useCallback((id: number, data: UpdateSiteData) => {
    return updateSiteMutation.mutateAsync({ id, data })
  }, [updateSiteMutation])

  const deleteSiteHandler = useCallback((id: number) => {
    return deleteSiteMutation.mutateAsync(id)
  }, [deleteSiteMutation])

  const geocodeAddressHandler = useCallback((address: string) => {
    return geocodeMutation.mutateAsync(address)
  }, [geocodeMutation])

  // ==================== RETURN ====================

  const error = queryError as Error | null

  return {
    sites,
    isLoading,
    error,
    refetch,
    createSite: createSiteHandler,
    updateSite: updateSiteHandler,
    deleteSite: deleteSiteHandler,
    geocodeAddress: geocodeAddressHandler
  }
}

// ==================== EXPORT ====================

export default useSiteList
