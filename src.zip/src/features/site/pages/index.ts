/**
 * Site Pages Export Index
 * Point d'entrée centralisé pour toutes les pages de gestion des sites
 */

export { SiteListPage } from './SiteListPage'
export { SiteDetailPage } from './SiteDetailPage'