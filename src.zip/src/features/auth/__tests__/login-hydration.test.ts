/**
 * Login + Hydration E2E (local backend)
 * - Login against http://localhost:3313
 * - Validate payload shape (id, roles, machines, sites)
 * - Persist auth token in localStorage via httpClient TokenManager
 * - Hydrate TrackBeeDB (Dexie) with machines/sites/installations
 */

// Provide IndexedDB in JSDOM
import 'fake-indexeddb/auto'

import axios from 'axios'
import { describe, it, expect, beforeAll } from 'vitest'

import { database } from '@/core/database/schema'
import { httpClient } from '@/core/services/api/HttpClient'
import { AuthService } from '@/core/services/api/services/AuthService'
import { HydrationService } from '@/core/services/hydration/HydrationService'
import type { LoginResponse } from '@/features/auth/types'

const API_BASE_URL = import.meta.env.VITE_SERVER_ADDRESS_LOCAL || 'http://localhost:3313'
const DEBUG_LOGIN = import.meta.env.VITE_DEBUG_MODERATOR_LOGIN || 'moderator1@test.com'
const DEBUG_PASSWORD = import.meta.env.VITE_DEBUG_MODERATOR_PASSWORD || 'test'

type HydratableLoginResponse = Parameters<typeof AuthService.extractHydrationData>[0]

interface LoginPayloadWithHydration extends HydratableLoginResponse {
  machines: unknown[]
  sites: unknown
  roles?: unknown
}

function assertHydratableLoginResponse(payload: unknown): asserts payload is LoginPayloadWithHydration {
  if (!payload || typeof payload !== 'object') {
    throw new Error('Invalid login response payload')
  }

  const record = payload as Record<string, unknown>

  if (typeof record.token !== 'string') {
    throw new Error('Login payload missing token')
  }

  if (typeof record.expiresAt !== 'string') {
    throw new Error('Login payload missing expiration timestamp')
  }

  if (!record.user || typeof record.user !== 'object') {
    throw new Error('Login payload missing user data')
  }

  if (!Array.isArray(record.machines)) {
    throw new Error('Login payload missing machines collection')
  }

  if (!record.sites || typeof record.sites !== 'object') {
    throw new Error('Login payload missing sites collection')
  }
}

describe('Auth Login and Hydration', () => {
  beforeAll(async () => {
    // Cleanup DB before test
    await database.delete()
    await database.open()
    // Clear storage
    localStorage.clear()
  })

  it('logs in, stores token, and hydrates TrackBeeDB', async () => {
    // 1) Login to backend
    const resp = await axios.post<LoginResponse>(`${API_BASE_URL}/api/auth/signin`, {
      email: DEBUG_LOGIN,
      password: DEBUG_PASSWORD
    }, {
      headers: { 'Content-Type': 'application/json' },
      timeout: 10000
    })

    expect(resp.status).toBe(200)
    const loginData = resp.data
    assertHydratableLoginResponse(loginData)
    const typedLoginData = loginData

    // 2) Validate minimal payload shape
    expect(typedLoginData).toHaveProperty('id')
    expect(Array.isArray(typedLoginData.roles)).toBe(true)
    expect(Array.isArray(typedLoginData.machines)).toBe(true)
    expect(typedLoginData).toHaveProperty('sites')
    expect(typedLoginData).toHaveProperty('token')

    // 3) Store token in localStorage via httpClient
    const expiresAt = Date.now() + 24 * 60 * 60 * 1000
    await httpClient.setAuthToken(typedLoginData.token, typedLoginData.refreshToken, expiresAt)
    expect(localStorage.getItem('auth_token')).toBeTruthy()

    // 4) Extract hydration data from backend payload
    const hydration = AuthService.extractHydrationData(typedLoginData)
    expect(Array.isArray(hydration.machines)).toBe(true)
    expect(Array.isArray(hydration.sites)).toBe(true)
    expect(Array.isArray(hydration.installations)).toBe(true)

    // 5) Persist to Dexie (TrackBeeDB)
    await HydrationService.syncToDexie(hydration)

    // 6) Validate persisted counts
    const machinesCount = await database.machines.count()
    const sitesCount = await database.sites.count()
    const installationsCount = await database.installations.count()

    expect(machinesCount).toBeGreaterThanOrEqual(0)
    expect(sitesCount).toBeGreaterThanOrEqual(0)
    expect(installationsCount).toBeGreaterThanOrEqual(0)
  }, 20000)
})

