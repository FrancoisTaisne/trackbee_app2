/**
 * Auth Pages Export Index
 * Point d'entrée centralisé pour toutes les pages d'authentification
 */

export { ProfilePage } from './ProfilePage'