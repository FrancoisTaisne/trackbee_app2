/**
 * useDownloadMetrics Hook - Système de tracking et statistiques de téléchargement
 * Permet de tracker les performances, les erreurs et les tendances des téléchargements
 */

import { useState, useCallback, useRef } from 'react'
import { openDB, IDBPDatabase } from 'idb'
import { logger } from '@/core/utils/logger'

// ==================== TYPES ====================

export interface DownloadSession {
  id: string
  machineId: number
  campaignId: number
  method: 'wifi' | 'ble' | 'auto'
  startTime: number
  endTime?: number
  duration?: number
  success: boolean
  fileCount: number
  expectedBytes: number
  actualBytes: number
  errorMessage?: string
  phases: DownloadPhase[]
  retryAttempts: number
}

export interface DownloadPhase {
  name: 'init' | 'wifi_connect' | 'ble_connect' | 'download' | 'store' | 'upload' | 'cleanup'
  startTime: number
  endTime?: number
  duration?: number
  method?: 'wifi' | 'ble'
  bytes?: number
  files?: number
}

export interface DownloadProgress {
  current: number
  total: number
  bytes?: number
  method?: 'wifi' | 'ble'
}

export interface DownloadStats {
  total: number
  success: number
  failed: number
  successRate: number
  avgDuration: number
  avgSpeed: number
  totalBytes: number
  recentTrend: 'improving' | 'declining' | 'stable'
  methodStats: {
    [key: string]: {
      total: number
      successRate: number
      avgSpeed: number
      avgDuration: number
    }
  }
  lastSuccess: number | null
  lastFailure: number | null
}

// ==================== LOGGER ====================

const metricsLog = {
  debug: (msg: string, data?: unknown) => logger.debug('downloadMetrics', msg, data),
  info: (msg: string, data?: unknown) => logger.info('downloadMetrics', msg, data),
  warn: (msg: string, data?: unknown) => logger.warn('downloadMetrics', msg, data),
  error: (msg: string, data?: unknown) => logger.error('downloadMetrics', msg, data)
}

// ==================== DATABASE ====================

const DB_NAME = 'trackbee_download_metrics'
const DB_VERSION = 1
const STORE_NAME = 'sessions'

let dbInstance: IDBPDatabase | null = null

async function getDB(): Promise<IDBPDatabase> {
  if (dbInstance) return dbInstance

  dbInstance = await openDB(DB_NAME, DB_VERSION, {
    upgrade(db) {
      if (!db.objectStoreNames.contains(STORE_NAME)) {
        const store = db.createObjectStore(STORE_NAME, { keyPath: 'id' })
        store.createIndex('machineId', 'machineId', { unique: false })
        store.createIndex('startTime', 'startTime', { unique: false })
        store.createIndex('success', 'success', { unique: false })
      }
    }
  })

  return dbInstance
}

// ==================== UTILITY FUNCTIONS ====================

function generateSessionId(): string {
  return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
}

function calculateTrend(sessions: DownloadSession[]): 'improving' | 'declining' | 'stable' {
  if (sessions.length < 5) return 'stable'

  const recent = sessions.slice(-5)
  const older = sessions.slice(-10, -5)

  if (older.length === 0) return 'stable'

  const recentAvgDuration = recent.reduce((sum, s) => sum + (s.duration || 0), 0) / recent.length
  const olderAvgDuration = older.reduce((sum, s) => sum + (s.duration || 0), 0) / older.length

  const improvement = (olderAvgDuration - recentAvgDuration) / olderAvgDuration

  if (improvement > 0.1) return 'improving'
  if (improvement < -0.1) return 'declining'
  return 'stable'
}

// ==================== HOOK ====================

export function useDownloadMetrics() {
  const [currentSession, setCurrentSession] = useState<DownloadSession | null>(null)
  const currentPhaseRef = useRef<DownloadPhase | null>(null)

  /**
   * Démarre une nouvelle session de téléchargement
   */
  const startSession = useCallback((params: {
    machineId: number
    campaignId: number
    method: 'wifi' | 'ble' | 'auto'
    fileCount: number
    expectedBytes: number
  }): string => {
    const sessionId = generateSessionId()

    const session: DownloadSession = {
      id: sessionId,
      machineId: params.machineId,
      campaignId: params.campaignId,
      method: params.method,
      startTime: Date.now(),
      success: false,
      fileCount: params.fileCount,
      expectedBytes: params.expectedBytes,
      actualBytes: 0,
      phases: [],
      retryAttempts: 0
    }

    setCurrentSession(session)
    metricsLog.info('Download session started', { sessionId, machineId: params.machineId })

    return sessionId
  }, [])

  /**
   * Démarre une nouvelle phase
   */
  const startPhase = useCallback((name: DownloadPhase['name']) => {
    if (!currentSession) {
      metricsLog.warn('Cannot start phase: no active session')
      return
    }

    // Terminer la phase précédente si elle existe
    if (currentPhaseRef.current && !currentPhaseRef.current.endTime) {
      currentPhaseRef.current.endTime = Date.now()
      currentPhaseRef.current.duration = currentPhaseRef.current.endTime - currentPhaseRef.current.startTime
    }

    const phase: DownloadPhase = {
      name,
      startTime: Date.now()
    }

    currentPhaseRef.current = phase
    setCurrentSession(prev => {
      if (!prev) return null
      return {
        ...prev,
        phases: [...prev.phases, phase]
      }
    })

    metricsLog.debug('Phase started', { phase: name, sessionId: currentSession.id })
  }, [currentSession])

  /**
   * Termine la phase courante
   */
  const endPhase = useCallback((phaseName?: string, data?: { method?: 'wifi' | 'ble', bytes?: number, files?: number }) => {
    if (!currentPhaseRef.current) return

    currentPhaseRef.current.endTime = Date.now()
    currentPhaseRef.current.duration = currentPhaseRef.current.endTime - currentPhaseRef.current.startTime

    if (data) {
      if (data.method) currentPhaseRef.current.method = data.method
      if (data.bytes) currentPhaseRef.current.bytes = data.bytes
      if (data.files) currentPhaseRef.current.files = data.files
    }

    metricsLog.debug('Phase ended', {
      phase: currentPhaseRef.current.name,
      duration: currentPhaseRef.current.duration,
      ...data
    })

    currentPhaseRef.current = null
  }, [])

  /**
   * Met à jour le progress
   */
  const updateProgress = useCallback((progress: DownloadProgress) => {
    if (!currentSession) return

    setCurrentSession(prev => {
      if (!prev) return null
      return {
        ...prev,
        actualBytes: progress.bytes || prev.actualBytes
      }
    })
  }, [currentSession])

  /**
   * Enregistre une tentative de retry
   */
  const recordRetryAttempt = useCallback(() => {
    setCurrentSession(prev => {
      if (!prev) return null
      return {
        ...prev,
        retryAttempts: prev.retryAttempts + 1
      }
    })
    metricsLog.warn('Retry attempt recorded', { retryCount: (currentSession?.retryAttempts || 0) + 1 })
  }, [currentSession])

  /**
   * Termine la session
   */
  const endSession = useCallback(async (success: boolean, errorMessage?: string) => {
    if (!currentSession) {
      metricsLog.warn('Cannot end session: no active session')
      return
    }

    // Terminer la phase courante si elle existe
    if (currentPhaseRef.current && !currentPhaseRef.current.endTime) {
      endPhase()
    }

    const endTime = Date.now()
    const finalSession: DownloadSession = {
      ...currentSession,
      endTime,
      duration: endTime - currentSession.startTime,
      success,
      errorMessage
    }

    // Sauvegarder dans IndexedDB
    try {
      const db = await getDB()
      await db.add(STORE_NAME, finalSession)
      metricsLog.info('Session saved to database', {
        sessionId: finalSession.id,
        success,
        duration: finalSession.duration
      })
    } catch (error) {
      metricsLog.error('Failed to save session to database', error)
    }

    setCurrentSession(null)
    currentPhaseRef.current = null
  }, [currentSession, endPhase])

  /**
   * Récupère les statistiques
   */
  const getStats = useCallback(async (filter?: { machineId?: number }): Promise<DownloadStats> => {
    try {
      const db = await getDB()
      let sessions: DownloadSession[] = await db.getAll(STORE_NAME)

      // Filtrer par machineId si spécifié
      if (filter?.machineId) {
        sessions = sessions.filter(s => s.machineId === filter.machineId)
      }

      // Trier par date
      sessions.sort((a, b) => b.startTime - a.startTime)

      const total = sessions.length
      const success = sessions.filter(s => s.success).length
      const failed = total - success
      const successRate = total > 0 ? Math.round((success / total) * 100) : 0

      const successfulSessions = sessions.filter(s => s.success && s.duration)
      const avgDuration = successfulSessions.length > 0
        ? successfulSessions.reduce((sum, s) => sum + (s.duration || 0), 0) / successfulSessions.length
        : 0

      const totalBytes = sessions.reduce((sum, s) => sum + s.actualBytes, 0)
      const avgSpeed = avgDuration > 0 ? (totalBytes / (avgDuration / 1000)) : 0

      const recentTrend = calculateTrend(sessions)

      // Stats par méthode
      const methodStats: DownloadStats['methodStats'] = {}
      const methods = ['wifi', 'ble', 'auto']

      methods.forEach(method => {
        const methodSessions = sessions.filter(s => s.method === method)
        if (methodSessions.length === 0) return

        const methodSuccess = methodSessions.filter(s => s.success).length
        const methodSuccessRate = Math.round((methodSuccess / methodSessions.length) * 100)

        const successfulMethodSessions = methodSessions.filter(s => s.success && s.duration)
        const methodAvgDuration = successfulMethodSessions.length > 0
          ? successfulMethodSessions.reduce((sum, s) => sum + (s.duration || 0), 0) / successfulMethodSessions.length
          : 0

        const methodBytes = methodSessions.reduce((sum, s) => sum + s.actualBytes, 0)
        const methodAvgSpeed = methodAvgDuration > 0 ? (methodBytes / (methodAvgDuration / 1000)) : 0

        methodStats[method] = {
          total: methodSessions.length,
          successRate: methodSuccessRate,
          avgSpeed: methodAvgSpeed,
          avgDuration: methodAvgDuration
        }
      })

      const lastSuccessSession = sessions.find(s => s.success)
      const lastFailureSession = sessions.find(s => !s.success)

      return {
        total,
        success,
        failed,
        successRate,
        avgDuration,
        avgSpeed,
        totalBytes,
        recentTrend,
        methodStats,
        lastSuccess: lastSuccessSession?.startTime || null,
        lastFailure: lastFailureSession?.startTime || null
      }
    } catch (error) {
      metricsLog.error('Failed to get stats', error)
      return {
        total: 0,
        success: 0,
        failed: 0,
        successRate: 0,
        avgDuration: 0,
        avgSpeed: 0,
        totalBytes: 0,
        recentTrend: 'stable',
        methodStats: {},
        lastSuccess: null,
        lastFailure: null
      }
    }
  }, [])

  /**
   * Formate les octets en format lisible
   */
  const formatBytes = useCallback((bytes: number): string => {
    if (bytes === 0) return '0 B'
    const k = 1024
    const sizes = ['B', 'KB', 'MB', 'GB']
    const i = Math.floor(Math.log(bytes) / Math.log(k))
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(2))} ${sizes[i]}`
  }, [])

  /**
   * Formate la durée en format lisible
   */
  const formatDuration = useCallback((ms: number): string => {
    if (ms < 1000) return `${ms}ms`
    if (ms < 60000) return `${(ms / 1000).toFixed(1)}s`
    const minutes = Math.floor(ms / 60000)
    const seconds = Math.floor((ms % 60000) / 1000)
    return `${minutes}m ${seconds}s`
  }, [])

  return {
    // Session management
    startSession,
    endSession,

    // Phase management
    startPhase,
    endPhase,

    // Progress
    updateProgress,
    recordRetryAttempt,

    // Stats
    getStats,

    // Utils
    formatBytes,
    formatDuration,

    // Current session (pour debug)
    currentSession
  }
}

// ==================== EXPORT ====================

export default useDownloadMetrics
