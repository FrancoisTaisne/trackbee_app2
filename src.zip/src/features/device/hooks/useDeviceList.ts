/**
 * useDeviceList Hook - Gestion de la liste des devices
 * Interface pour lister, filtrer, créer et supprimer des devices
 * REFACTORED: Utilise désormais useHydrate pour une approche centralisée
 */

import { useCallback, useMemo } from 'react'
import { useMutation, useQueryClient } from '@tanstack/react-query'
import { useDeviceStore } from '@/core/state/stores/device.store'
import { useBleStore } from '@/core/state/stores/bleStore'
import { useEventBus } from '@/core/orchestrator/EventBus'
import { useHydrate } from '@/core/hooks/useHydrate'
import { httpClient } from '@/core/services/api/HttpClient'
import { logger } from '@/core/utils/logger'
import type { AppError } from '@/core/types/common'
import { deviceQueryKeys } from './useDevice'
import type {
  DeviceBundle,
  CreateDeviceData,
  UpdateDeviceData,
  UseDeviceListReturn,
  DeviceError,
  DeviceErrorMessages
} from '../types'
import type { Machine, Site, Installation } from '@/core/types'

// ==================== LOGGER SETUP ====================

const deviceListLog = {
  trace: (msg: string, data?: unknown) => logger.trace('deviceList', msg, data),
  debug: (msg: string, data?: unknown) => logger.debug('deviceList', msg, data),
  info: (msg: string, data?: unknown) => logger.info('deviceList', msg, data),
  warn: (msg: string, data?: unknown) => logger.warn('deviceList', msg, data),
  error: (msg: string, data?: unknown) => logger.error('deviceList', msg, data)
}

// ==================== API FUNCTIONS ====================

/**
 * Récupère tous les devices avec leurs relations - Backend First Strategy
 */
const _fetchDeviceBundles = async (): Promise<DeviceBundle[]> => {
  deviceListLog.debug('🔄 Fetching device bundles - Backend First Strategy...')

  // ÉTAPE 1: Essayer d'abord le backend (source de vérité)
  try {
    deviceListLog.debug('🌐 Attempting backend fetch first...')

    // Récupérer les données du backend avec les vraies routes
    const [machinesResp, sitesResp] = await Promise.all([
      httpClient.get<Machine[]>('/api/machine/allByMod').catch(() =>
        httpClient.get<Machine[]>('/api/machine/all').catch(() => ({ data: [] as Machine[], success: true, timestamp: Date.now() }))
      ),
      httpClient.get<Site[]>('/api/site').catch(() => ({ data: [] as Site[], success: true, timestamp: Date.now() }))
      // Note: pas de route installations globale, sera géré par machine ou site
    ])

    // Unwrap API responses
    const machines = machinesResp.data || []
    const sites = sitesResp.data || []

    // Les installations sont récupérées via les machines ou sites individuellement
    const installations: Installation[] = []

    deviceListLog.info('✅ Backend data fetched successfully', {
      machines: machines.length,
      sites: sites.length,
      installations: installations.length
    })

    // Construire les bundles depuis les données backend

    const backendBundles: DeviceBundle[] = machines.map(machine => {
      const machineInstallation = installations.find(inst => inst.machineId === machine.id)
      const machineSite = machineInstallation
        ? sites.find(site => site.id === machineInstallation.siteId)
        : undefined

      return {
        machine: {
          id: machine.id,
          name: machine.name || '',
          macD: machine.macD || '',
          macAddress: machine.macAddress || machine.macD || '',
          model: machine.model || '',
          isActive: machine.isActive ?? true,
          lastSeen: machine.lastSeen,
          description: machine.description || '',
          type: machine.type || 'trackbee',
          createdAt: machine.createdAt || new Date().toISOString(),
          updatedAt: machine.updatedAt || new Date().toISOString()
        },
        installation: machineInstallation ? {
          id: machineInstallation.id,
          machineId: machine.id,
          siteId: machineInstallation.siteId,
          isActive: machineInstallation.isActive,
          installedAt: new Date(machineInstallation.createdAt || Date.now()),
          createdAt: new Date(machineInstallation.createdAt || Date.now()),
          updatedAt: new Date(machineInstallation.updatedAt || Date.now())
        } : undefined,
        site: machineSite ? {
          id: machineSite.id,
          name: machineSite.name,
          description: machineSite.description || '',
          coordinates: machineSite.lat && machineSite.lng ? {
            latitude: machineSite.lat,
            longitude: machineSite.lng
          } : undefined,
          address: machineSite.address || '',
          isActive: true,
          createdAt: new Date(machineSite.createdAt || Date.now()),
          updatedAt: new Date(machineSite.updatedAt || Date.now())
        } : undefined,
        campaigns: [], // TODO: Récupérer campaigns depuis backend
        calculations: [] // TODO: Récupérer calculations depuis backend
      }
    })

    // 🎯 HYDRATATION AUTOMATIQUE - Synchroniser avec IndexedDB
    try {
      deviceListLog.debug('💾 Hydrating IndexedDB with backend data...')
      await hydrateIndexedDBWithMachineData(machines, sites, installations)
      deviceListLog.info('✅ IndexedDB hydrated successfully with machine data')
    } catch (hydrationError) {
      deviceListLog.warn('⚠️ Failed to hydrate IndexedDB with machine data', { hydrationError })
    }

    return backendBundles

  } catch (backendError) {
    deviceListLog.warn('⚠️ Backend fetch failed, falling back to IndexedDB...', { backendError })

    // ÉTAPE 2: Fallback vers IndexedDB si backend échoue
    try {
      const { DataService } = await import('@/core/services/data/DataService')
      const bundles = await DataService.buildDeviceBundles()

      const deviceBundles: DeviceBundle[] = bundles.map(bundle => ({
        machine: {
          id: bundle.id,
          name: bundle.name,
          macAddress: bundle.macAddress,
          model: bundle.model,
          isActive: bundle.isActive,
          lastConnectionState: bundle.connected ? 'connected' : 'disconnected',
          lastSeenAt: bundle.lastSeenAt,
          description: '',
          type: 'trackbee',
          createdAt: new Date(),
          updatedAt: new Date()
        },
        installation: bundle.installation ? {
          id: bundle.installation.id,
          machineId: bundle.id,
          siteId: bundle.site?.id || 0,
          isActive: bundle.installation.isActive,
          installedAt: bundle.installation.installedAt,
          createdAt: bundle.installation.installedAt,
          updatedAt: bundle.installation.installedAt
        } : undefined,
        site: bundle.site ? {
          id: bundle.site.id,
          name: bundle.site.name,
          description: '',
          coordinates: bundle.site.location?.latitude && bundle.site.location?.longitude ? {
            latitude: bundle.site.location.latitude,
            longitude: bundle.site.location.longitude
          } : undefined,
          address: '',
          isActive: true,
          createdAt: new Date(),
          updatedAt: new Date()
        } : undefined,
        campaigns: [],
        calculations: []
      }))

      deviceListLog.info('✅ Device bundles fetched from IndexedDB fallback', { count: deviceBundles.length })
      return deviceBundles

    } catch (indexedError) {
      deviceListLog.error('❌ Both backend and IndexedDB failed', { backendError, indexedError })
      return []
    }
  }
}

/**
 * Hydratation automatique d'IndexedDB avec les données machines du backend
 */
const hydrateIndexedDBWithMachineData = async (
  machines: Machine[],
  sites: Site[],
  installations: Installation[]
): Promise<void> => {
  try {
    const { database } = await import('@/core/database/schema')

    // Hydratation des machines
    await Promise.all(machines.map(machine =>
      database.machines.put({
        id: machine.id,
        name: machine.name || '',
        macAddress: machine.macAddress || machine.macD || '',
        macD: machine.macD || '',
        model: machine.model || '',
        isActive: machine.isActive ?? true,
        lastSeen: machine.lastSeen,
        createdAt: machine.createdAt || new Date().toISOString(),
        updatedAt: machine.updatedAt || new Date().toISOString(),
        syncedAt: new Date()
      })
    ))

    // Hydratation des sites (si pas déjà fait)
    await Promise.all(sites.map(site =>
      database.sites.put({
        id: site.id,
        name: site.name,
        description: site.description || '',
        address: site.address || '',
        lat: site.lat || undefined,
        lng: site.lng || undefined,
        altitude: site.altitude || undefined,
        isActive: true,
        createdAt: site.createdAt || new Date().toISOString(),
        updatedAt: site.updatedAt || new Date().toISOString(),
        syncedAt: new Date()
      })
    ))

    // Hydratation des installations
    await Promise.all(installations.map(installation =>
      database.installations.put({
        id: String(installation.id),
        machineId: String(installation.machineId),
        siteId: String(installation.siteId),
        isActive: installation.isActive ? 1 : 0,
        createdAt: new Date(installation.createdAt || Date.now()),
        updatedAt: new Date(installation.updatedAt || Date.now()),
        syncedAt: new Date()
      })
    ))

    // Marquer la dernière synchronisation machine
    await database.setAppState('lastMachineSync', new Date())

    deviceListLog.debug('💾 IndexedDB machine hydration completed', {
      machines: machines.length,
      sites: sites.length,
      installations: installations.length
    })

  } catch (error) {
    deviceListLog.error('❌ IndexedDB machine hydration failed', { error })
    throw error
  }
}

/**
 * Crée un nouveau device
 */
const createDevice = async (data: CreateDeviceData): Promise<Machine> => {
  deviceListLog.debug('Creating device', { data })

  // Valider les données avant envoi
  if (!data.name.trim()) {
    throw new AppError('Le nom du device est obligatoire', 'VALIDATION_ERROR')
  }

  if (!data.macAddress.match(/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/)) {
    throw new AppError('Format d\'adresse MAC invalide', 'VALIDATION_ERROR')
  }

  const response = await httpClient.post<Machine>('/api/machine/create', {
    name: data.name.trim(),
    description: data.description?.trim(),
    macAddress: data.macAddress.toUpperCase(),
    type: data.type || 'trackbee',
    model: data.model?.trim(),
    isActive: true
  })

  deviceListLog.info('Device created successfully', { device: response })
  return response
}

/**
 * Met à jour un device
 */
const updateDevice = async (id: number, data: UpdateDeviceData): Promise<Machine> => {
  deviceListLog.debug('Updating device', { id, data })

  const response = await httpClient.put<Machine>(`/api/machine/${id}`, data)

  deviceListLog.info('Device updated successfully', { device: response })
  return response
}

/**
 * Supprime un device
 */
const deleteDevice = async (id: number): Promise<void> => {
  deviceListLog.debug('Deleting device', { id })

  // Vérifier si le device peut être supprimé
  const installations = await httpClient.get<Installation[]>(`/api/machine/${id}/installations`)
  if (installations.length > 0) {
    throw new AppError(
      'Impossible de supprimer un device associé à un site. Retirez-le d\'abord du site.',
      'CONSTRAINT_VIOLATION'
    )
  }

  await httpClient.delete(`/api/machine/${id}`)

  deviceListLog.info('Device deleted successfully', { id })
}

// ==================== DEVICE ERROR HELPER ====================

const createDeviceError = (type: DeviceError, originalError?: Error): AppError => {
  return new AppError(
    DeviceErrorMessages[type],
    type,
    'DEVICE',
    originalError
  )
}

// ==================== MAIN HOOK ====================

/**
 * Hook pour la gestion de la liste des devices
 */
export const useDeviceList = (filters?: {
  search?: string
  siteId?: number
  connected?: boolean
  active?: boolean
}): UseDeviceListReturn => {
  const queryClient = useQueryClient()
  const eventBus = useEventBus()
  const deviceStore = useDeviceStore()
  const bleConnections = useBleStore(state => state.connections)
  const removeBleConnection = useBleStore(state => state.removeConnection)

  // ==================== USE HYDRATE DATA ====================

  const { machines, sites, isLoading: hydrateLoading, error: hydrateError, refetch } = useHydrate()

  const sanitizeMachineId = (id: unknown): number | null => {
    const parsed = typeof id === 'string' ? Number(id) : id
    return Number.isInteger(parsed) && (parsed as number) > 0 ? (parsed as number) : null
  }

  // Construire les bundles depuis les données hydratées
  const rawDevices = useMemo(() => {
    if (!machines || !sites) return []

    deviceListLog.debug('🎯 Building device bundles from hydrated data', {
      machines: machines.length,
      sites: sites.length
    })

    const bundles: DeviceBundle[] = machines
      .map(machine => {
        const machineId = sanitizeMachineId(machine.id)
        if (!machineId) {
          deviceListLog.warn('Skipping machine with invalid id', { rawId: machine.id })
          return null
        }

        // Trouver le site associé via installation (logique simplifiée)
        const site = sites.find(s => s.id === machine.installation?.siteId)

        return {
        machine: {
          id: machineId,
          name: machine.name || '',
          macAddress: machine.macAddress || '',
          model: machine.model || '',
          isActive: machine.isActive ?? true,
          lastConnectionState: 'disconnected',
          lastSeenAt: undefined,
          description: machine.description || '',
          type: machine.type || 'trackbee',
          createdAt: new Date(machine.createdAt || Date.now()),
          updatedAt: new Date(machine.updatedAt || Date.now())
        },
        installation: machine.installation,
        site: site ? {
          id: site.id,
          name: site.name,
          description: site.description || '',
          coordinates: site.lat && site.lng ? {
            latitude: site.lat,
            longitude: site.lng
          } : undefined,
          address: site.address || '',
          isActive: true,
          createdAt: new Date(site.createdAt || Date.now()),
          updatedAt: new Date(site.updatedAt || Date.now())
        } : undefined,
        campaigns: [],
        calculations: []
      }
      })
      .filter((bundle): bundle is DeviceBundle => bundle !== null)

    deviceListLog.info('✅ Device bundles built from hydrated data', { count: bundles.length })
    return bundles
  }, [machines, sites])

  const isLoading = hydrateLoading
  const queryError = hydrateError

  // ==================== FILTERED DEVICES ====================

  const devices = useMemo(() => {
    let filtered = [...rawDevices]

    // Ajouter l'état de connexion BLE à chaque device
    filtered = filtered.map(bundle => ({
      ...bundle,
      bleConnection: bleConnections[bundle.machine.id]
    }))

    // Filtrage par recherche textuelle
    if (filters?.search) {
      const searchLower = filters.search.toLowerCase()
      filtered = filtered.filter(bundle =>
        bundle.machine.name.toLowerCase().includes(searchLower) ||
        bundle.machine.description?.toLowerCase().includes(searchLower) ||
        bundle.machine.macAddress.toLowerCase().includes(searchLower) ||
        bundle.site?.name.toLowerCase().includes(searchLower)
      )
    }

    // Filtrage par site
    if (filters?.siteId !== undefined) {
      filtered = filtered.filter(bundle =>
        bundle.installation?.siteId === filters.siteId
      )
    }

    // Filtrage par état de connexion
    if (filters?.connected !== undefined) {
      filtered = filtered.filter(bundle => {
        const connection = bleConnections[bundle.machine.id]
        const isConnected = connection?.status === 'connected'
        return filters.connected ? isConnected : !isConnected
      })
    }

    // Filtrage par statut actif
    if (filters?.active !== undefined) {
      filtered = filtered.filter(bundle =>
        bundle.machine.isActive === filters.active
      )
    }

    // Tri par nom
    filtered.sort((a, b) => a.machine.name.localeCompare(b.machine.name))

    deviceListLog.debug('Devices filtered', {
      total: rawDevices.length,
      filtered: filtered.length,
      filters
    })

    return filtered
  }, [rawDevices, bleConnections, filters])

  // ==================== MUTATIONS ====================

  const createDeviceMutation = useMutation({
    mutationFn: createDevice,
    onSuccess: (newDevice) => {
      // Invalider les caches
      queryClient.invalidateQueries({ queryKey: deviceQueryKeys.lists() })

      // Mettre à jour le store local
      deviceStore.addDevice(newDevice)

      // Événement global
      eventBus.emit('device:created', { device: newDevice })

      deviceListLog.info('Device created and caches updated', { device: newDevice })
    },
    onError: (error) => {
      deviceListLog.error('Device creation failed', error)
      throw createDeviceError('DEVICE_ALREADY_EXISTS', error as Error)
    }
  })

  const updateDeviceMutation = useMutation({
    mutationFn: ({ id, data }: { id: number; data: UpdateDeviceData }) =>
      updateDevice(id, data),
    onSuccess: (updatedDevice) => {
      // Invalider les caches spécifiques
      queryClient.invalidateQueries({ queryKey: deviceQueryKeys.lists() })
      queryClient.invalidateQueries({ queryKey: deviceQueryKeys.detail(updatedDevice.id) })
      queryClient.invalidateQueries({ queryKey: deviceQueryKeys.bundle(updatedDevice.id) })

      // Mettre à jour le store local
      deviceStore.updateDevice(updatedDevice.id, updatedDevice)

      // Événement global
      eventBus.emit('device:updated', { deviceId: updatedDevice.id, device: updatedDevice })

      deviceListLog.info('Device updated and caches invalidated', { device: updatedDevice })
    },
    onError: (error) => {
      deviceListLog.error('Device update failed', error)
      throw createDeviceError('DEVICE_NOT_FOUND', error as Error)
    }
  })

  const deleteDeviceMutation = useMutation({
    mutationFn: deleteDevice,
    onSuccess: (_, deletedId) => {
      // Invalider les caches
      queryClient.invalidateQueries({ queryKey: deviceQueryKeys.lists() })
      queryClient.removeQueries({ queryKey: deviceQueryKeys.detail(deletedId) })
      queryClient.removeQueries({ queryKey: deviceQueryKeys.bundle(deletedId) })

      // Nettoyer le store local
      deviceStore.removeDevice(deletedId)

      // Nettoyer la connexion BLE si elle existe
      removeBleConnection(deletedId)

      // Événement global
      eventBus.emit('device:deleted', { deviceId: deletedId })

      deviceListLog.info('Device deleted and cleaned up', { deviceId: deletedId })
    },
    onError: (error) => {
      deviceListLog.error('Device deletion failed', error)
      throw createDeviceError('DEVICE_NOT_FOUND', error as Error)
    }
  })

  // ==================== SCAN FUNCTIONALITY ====================

  const scanForDevices = useCallback(async (options = {}) => {
    deviceListLog.debug('Scanning for devices', { options })

    try {
      // Cette fonction sera implémentée dans useDeviceScan
      // Pour l'instant, on retourne une liste vide
      deviceListLog.warn('Device scanning not yet implemented')
      return []

    } catch (error) {
      deviceListLog.error('Device scan failed', error)
      throw createDeviceError('BLE_SCAN_FAILED', error as Error)
    }
  }, [])

  // ==================== HELPER FUNCTIONS ====================

  const createDeviceHandler = useCallback((data: CreateDeviceData) => {
    return createDeviceMutation.mutateAsync(data)
  }, [createDeviceMutation])

  const updateDeviceHandler = useCallback((id: number, data: UpdateDeviceData) => {
    return updateDeviceMutation.mutateAsync({ id, data })
  }, [updateDeviceMutation])

  const deleteDeviceHandler = useCallback((id: number) => {
    return deleteDeviceMutation.mutateAsync(id)
  }, [deleteDeviceMutation])

  // ==================== RETURN ====================

  const error = queryError as Error | null

  return {
    devices,
    isLoading,
    error,
    refetch,
    createDevice: createDeviceHandler,
    updateDevice: updateDeviceHandler,
    deleteDevice: deleteDeviceHandler,
    scanForDevices
  }
}

// ==================== EXPORT ====================

export default useDeviceList
