/**
 * BleStatusPill Component - Pastille interactive d'état BLE
 * Affiche l'état de connexion BLE (ONLINE/CONNECTING/OFFLINE) avec switch visuel
 * Clic pour connecter/déconnecter le device
 */

import React, { useCallback } from 'react'
import { Loader2 } from 'lucide-react'
import { cn } from '@/core/utils/cn'
import { useDevice } from '../hooks/useDevice'
import { logger } from '@/core/utils/logger'

// ==================== TYPES ====================

export interface BleStatusPillProps {
  /**
   * ID de la machine
   */
  deviceId: number

  /**
   * ID de l'installation (optionnel, pour le contexte de connexion)
   */
  installationId?: number | null

  /**
   * ID du site (optionnel, pour le contexte de connexion)
   */
  siteId?: number | null

  /**
   * Taille de la pill
   */
  size?: 'sm' | 'md' | 'lg'

  /**
   * Afficher le label textuel
   */
  showLabel?: boolean

  /**
   * Callback lors du clic
   */
  onClick?: () => void

  /**
   * Classes CSS personnalisées
   */
  className?: string
}

type ConnectionStatus = 'connected' | 'connecting' | 'disconnected'

// ==================== LOGGER ====================

const pillLog = {
  debug: (msg: string, data?: unknown) => logger.debug('bleStatusPill', msg, data),
  info: (msg: string, data?: unknown) => logger.info('bleStatusPill', msg, data),
  warn: (msg: string, data?: unknown) => logger.warn('bleStatusPill', msg, data),
  error: (msg: string, data?: unknown) => logger.error('bleStatusPill', msg, data)
}

// ==================== CONFIGURATION ====================

const SIZE_CLASSES = {
  sm: {
    pill: 'px-3 py-1.5 text-[10px]',
    switch: 'w-8 h-5',
    dot: 'h-3 w-3',
    dotOn: 'translate-x-3',
    dotOff: 'translate-x-1',
    icon: 'h-3 w-3'
  },
  md: {
    pill: 'px-4 py-2 text-xs',
    switch: 'w-10 h-6',
    dot: 'h-4 w-4',
    dotOn: 'translate-x-4',
    dotOff: 'translate-x-1',
    icon: 'h-4 w-4'
  },
  lg: {
    pill: 'px-5 py-2.5 text-sm',
    switch: 'w-12 h-7',
    dot: 'h-5 w-5',
    dotOn: 'translate-x-5',
    dotOff: 'translate-x-1',
    icon: 'h-5 w-5'
  }
}

const STATUS_CONFIG = {
  connected: {
    label: 'ONLINE',
    colors: 'bg-green-600 hover:bg-green-700 focus-visible:ring-green-300',
    switchOn: true
  },
  connecting: {
    label: 'CONNECTING',
    colors: 'bg-yellow-500 hover:bg-yellow-600 focus-visible:ring-yellow-300',
    switchOn: false
  },
  disconnected: {
    label: 'OFFLINE',
    colors: 'bg-red-600 hover:bg-red-700 focus-visible:ring-red-300',
    switchOn: false
  }
}

// ==================== COMPONENT ====================

export const BleStatusPill: React.FC<BleStatusPillProps> = ({
  deviceId,
  installationId,
  siteId,
  size = 'md',
  showLabel = true,
  onClick,
  className
}) => {
  // Utiliser le hook useDevice pour accéder aux fonctions de connexion
  const {
    device,
    connectDevice,
    disconnectDevice
  } = useDevice(deviceId)

  const status: ConnectionStatus = device?.bleConnection?.status ?? 'disconnected'
  const config = STATUS_CONFIG[status]
  const sizeClasses = SIZE_CLASSES[size]

  /**
   * Handler du clic sur la pill
   */
  const handleClick = useCallback(async (e: React.MouseEvent) => {
    e.stopPropagation()

    // Si connecting, ne rien faire
    if (status === 'connecting') {
      pillLog.warn('Click ignored: connection in progress', { deviceId })
      return
    }

    pillLog.info('BleStatusPill clicked', { deviceId, status })

    // Callback externe
    onClick?.()

    try {
      if (status === 'connected') {
        // Déconnecter
        pillLog.info('Disconnecting device', { deviceId })
        await disconnectDevice()
      } else {
        // Connecter (avec scan automatique si nécessaire)
        pillLog.info('Connecting device', {
          deviceId,
          installationId,
          siteId
        })

        await connectDevice({
          autoScan: true,
          autoProbeFiles: true
        })
      }
    } catch (error) {
      pillLog.error('Failed to toggle connection', {
        deviceId,
        status,
        error
      })
    }
  }, [status, deviceId, installationId, siteId, onClick, connectDevice, disconnectDevice])

  return (
    <button
      type="button"
      onClick={handleClick}
      disabled={status === 'connecting'}
      aria-pressed={status === 'connected'}
      aria-busy={status === 'connecting'}
      aria-label={`État BLE: ${config.label}${status === 'connecting' ? ' - Connexion en cours' : status === 'connected' ? ' - Cliquer pour déconnecter' : ' - Cliquer pour connecter'}`}
      className={cn(
        'inline-flex items-center gap-3 rounded-full !text-white !border-0 font-black tracking-wider uppercase',
        'transition-all shadow-sm focus-visible:outline-none focus-visible:ring-4',
        'disabled:opacity-70 disabled:cursor-not-allowed',
        config.colors,
        sizeClasses.pill,
        className
      )}
    >
      {/* Switch visuel */}
      <span
        className={cn(
          'relative inline-flex items-center justify-start rounded-full bg-white/30',
          sizeClasses.switch
        )}
        aria-hidden="true"
      >
        <span
          className={cn(
            'rounded-full bg-white shadow transition-transform duration-200',
            sizeClasses.dot,
            config.switchOn ? sizeClasses.dotOn : sizeClasses.dotOff
          )}
        />
      </span>

      {/* Label */}
      {showLabel && (
        <span className="select-none">
          {status === 'connecting' ? (
            <span className="inline-flex items-center gap-2">
              <Loader2 className={cn('animate-spin', sizeClasses.icon)} />
              CONNECTING
            </span>
          ) : (
            config.label
          )}
        </span>
      )}
    </button>
  )
}

BleStatusPill.displayName = 'BleStatusPill'

// ==================== EXPORT ====================

export default BleStatusPill
