/**
 * CompactDownloadButton - Version minimaliste pour DeviceMiniBoard
 *
 * Affiche un bouton simple avec indication du nombre de fichiers disponibles
 */

import React from 'react'
import { Download } from 'lucide-react'
import { Button, Badge } from '@/shared/ui/components'
import { cn } from '@/core/utils/cn'
import type { DeviceBundle } from '../types'

export interface CompactDownloadButtonProps {
  device: DeviceBundle
  onDownload?: () => void
  className?: string
}

export const CompactDownloadButton: React.FC<CompactDownloadButtonProps> = ({
  device,
  onDownload,
  className
}) => {
  // Vérifier si le device est connecté en BLE
  const isConnected = device.bleConnection?.status === 'connected'

  // Compter les fichiers disponibles (à adapter selon votre logique métier)
  // Vérifier que campaigns est bien un tableau avant d'utiliser filter
  const campaigns = Array.isArray(device.campaigns) ? device.campaigns : []
  const fileCount = campaigns.filter(c => c.status === 'active').length || 0
  const hasFiles = fileCount > 0

  // Déterminer l'état du bouton
  const buttonVariant = !isConnected ? 'secondary' : hasFiles ? 'success' : 'warning'
  const buttonText = isConnected ? 'Download' : 'Déconnecté'

  return (
    <div className={cn('inline-flex items-center gap-2', className)}>
      <Button
        variant={buttonVariant}
        size="sm"
        onClick={onDownload}
        disabled={!isConnected}
        className="relative"
      >
        <Download className="w-3.5 h-3.5 mr-1.5" />
        {buttonText}

        {/* Badge nombre de fichiers */}
        {isConnected && fileCount > 0 && (
          <Badge
            variant="default"
            className="ml-2 bg-white text-gray-900 text-xs px-1.5 py-0.5 min-w-[1.25rem] h-5"
          >
            {fileCount}
          </Badge>
        )}
      </Button>
    </div>
  )
}

CompactDownloadButton.displayName = 'CompactDownloadButton'
