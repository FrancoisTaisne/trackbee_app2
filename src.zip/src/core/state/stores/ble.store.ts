/**
 * BLE Store - centralise le suivi des connexions BLE
 * Simplifie l'accès depuis les hooks device/site en évitant les erreurs runtime
 */

import { create } from 'zustand'
import type { BleConnectionState, BleFileInfo } from '@/core/types/transport'

type CampaignId = number

type ConnectionCollections = {
  activeCampaigns: Set<CampaignId>
  filesByCampaign: Map<CampaignId, BleFileInfo[]>
}

export type BleExtendedConnectionState = BleConnectionState & {
  lastConnection?: Date
  isScanning?: boolean
  isConnecting?: boolean
  isProbing?: boolean
  isDownloading?: boolean
  activeCampaigns: Set<CampaignId>
  filesByCampaign: Map<CampaignId, BleFileInfo[]>
}

interface BleStoreState {
  connections: Record<string, BleExtendedConnectionState>
  setConnection: (machineId: number | string, connection: Partial<BleExtendedConnectionState>) => void
  setConnectionState: (machineId: number | string, patch: Partial<BleExtendedConnectionState>) => void
  removeConnection: (machineId: number | string) => void
  getConnection: (machineId: number | string) => BleExtendedConnectionState | undefined
  reset: () => void
}

const toCampaignSet = (source?: Set<CampaignId> | CampaignId[] | null): Set<CampaignId> => {
  if (!source) {
    return new Set()
  }
  if (source instanceof Set) {
    return new Set(source)
  }
  return new Set(source)
}

const toFilesMap = (
  source?: Map<CampaignId, BleFileInfo[]> | Record<string, BleFileInfo[]> | null
): Map<CampaignId, BleFileInfo[]> => {
  if (!source) {
    return new Map()
  }
  if (source instanceof Map) {
    return new Map(source)
  }
  return new Map(
    Object.entries(source).map(([key, value]) => [Number(key), value as BleFileInfo[]])
  )
}

const createCollections = (prev?: ConnectionCollections, next?: Partial<ConnectionCollections>): ConnectionCollections => {
  const hasNextCampaigns = next && Object.prototype.hasOwnProperty.call(next, 'activeCampaigns')
  const hasNextFiles = next && Object.prototype.hasOwnProperty.call(next, 'filesByCampaign')

  return {
    activeCampaigns: hasNextCampaigns
      ? toCampaignSet(next?.activeCampaigns ?? null)
      : toCampaignSet(prev?.activeCampaigns ?? null),
    filesByCampaign: hasNextFiles
      ? toFilesMap(next?.filesByCampaign ?? null)
      : toFilesMap(prev?.filesByCampaign ?? null)
  }
}

const mergeConnection = (
  previous: BleExtendedConnectionState | undefined,
  patch: Partial<BleExtendedConnectionState>
): BleExtendedConnectionState => {
  const baseCollections = previous
    ? { activeCampaigns: previous.activeCampaigns, filesByCampaign: previous.filesByCampaign }
    : undefined

  const collections = createCollections(baseCollections, patch)

  return {
    status: patch.status ?? previous?.status ?? 'disconnected',
    deviceId: patch.deviceId ?? previous?.deviceId,
    deviceName: patch.deviceName ?? previous?.deviceName,
    rssi: patch.rssi ?? previous?.rssi,
    connectedAt: patch.connectedAt ?? previous?.connectedAt,
    lastConnection: patch.lastConnection ?? previous?.lastConnection,
    lastError: patch.lastError ?? previous?.lastError,
    retryCount: patch.retryCount ?? previous?.retryCount,
    error: patch.error ?? previous?.error,
    isScanning: patch.isScanning ?? previous?.isScanning ?? false,
    isConnecting: patch.isConnecting ?? previous?.isConnecting ?? false,
    isProbing: patch.isProbing ?? previous?.isProbing ?? false,
    isDownloading: patch.isDownloading ?? previous?.isDownloading ?? false,
    activeCampaigns: collections.activeCampaigns,
    filesByCampaign: collections.filesByCampaign
  }
}

export const useBleStore = create<BleStoreState>((set, get) => ({
  connections: {},

  setConnection: (machineId, connection) => {
    const key = String(machineId)
    set((state) => ({
      connections: {
        ...state.connections,
        [key]: mergeConnection(state.connections[key], connection)
      }
    }))
  },

  setConnectionState: (machineId, patch) => {
    const key = String(machineId)
    set((state) => ({
      connections: {
        ...state.connections,
        [key]: mergeConnection(state.connections[key], patch)
      }
    }))
  },

  removeConnection: (machineId) => {
    const key = String(machineId)
    set((state) => {
      if (!state.connections[key]) {
        return state
      }

      const { [key]: _removed, ...rest } = state.connections
      return { connections: rest }
    })
  },

  getConnection: (machineId) => {
    const key = String(machineId)
    return get().connections[key]
  },

  reset: () => {
    set({ connections: {} })
  }
}))

export type { BleStoreState }
