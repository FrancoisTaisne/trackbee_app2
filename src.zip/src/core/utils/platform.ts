/**
 * Platform Detection Utility
 * Détecte l'environnement d'exécution (Web, Android, iOS, Windows, etc.)
 */

import { Capacitor } from '@capacitor/core'

export type PlatformType = 'web' | 'android' | 'ios' | 'windows' | 'electron'

export interface PlatformInfo {
  type: PlatformType
  isNative: boolean
  isWeb: boolean
  isMobile: boolean
  isDesktop: boolean
  canUseBle: boolean
  canUseNativeBle: boolean
  os: string
  userAgent: string
}

/**
 * Détecte le type de plateforme
 */
export function getPlatformType(): PlatformType {
  // Capacitor natif (Android/iOS)
  if (Capacitor.isNativePlatform()) {
    const platform = Capacitor.getPlatform()
    if (platform === 'android') return 'android'
    if (platform === 'ios') return 'ios'
  }

  // Electron
  if (typeof navigator !== 'undefined' && navigator.userAgent.toLowerCase().includes('electron')) {
    return 'electron'
  }

  // Windows (web ou PWA)
  if (typeof navigator !== 'undefined' && /Win/i.test(navigator.platform || navigator.userAgent)) {
    return 'windows'
  }

  // Par défaut: web
  return 'web'
}

/**
 * Détecte si on est sur mobile
 */
export function isMobile(): boolean {
  if (Capacitor.isNativePlatform()) {
    return true
  }

  if (typeof navigator === 'undefined') {
    return false
  }

  const userAgent = navigator.userAgent.toLowerCase()
  return /android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(userAgent)
}

/**
 * Détecte si on est sur desktop
 */
export function isDesktop(): boolean {
  return !isMobile()
}

/**
 * Vérifie si le BLE est disponible
 */
export function canUseBle(): boolean {
  // Sur Android/iOS natif: toujours disponible via Capacitor
  if (Capacitor.isNativePlatform()) {
    return true
  }

  // Sur web: vérifier Web Bluetooth API
  if (typeof navigator !== 'undefined' && 'bluetooth' in navigator) {
    return true
  }

  return false
}

/**
 * Vérifie si on peut utiliser le BLE natif (Capacitor)
 */
export function canUseNativeBle(): boolean {
  return Capacitor.isNativePlatform()
}

/**
 * Obtient toutes les informations de plateforme
 */
export function getPlatformInfo(): PlatformInfo {
  const type = getPlatformType()
  const isNative = Capacitor.isNativePlatform()
  const isWeb = !isNative
  const mobile = isMobile()
  const desktop = isDesktop()

  return {
    type,
    isNative,
    isWeb,
    isMobile: mobile,
    isDesktop: desktop,
    canUseBle: canUseBle(),
    canUseNativeBle: canUseNativeBle(),
    os: typeof navigator !== 'undefined' ? navigator.platform : 'unknown',
    userAgent: typeof navigator !== 'undefined' ? navigator.userAgent : 'unknown'
  }
}

/**
 * Hook React pour obtenir les infos de plateforme
 */
export function usePlatform(): PlatformInfo {
  return getPlatformInfo()
}

/**
 * Logs les informations de plateforme (debug)
 */
export function logPlatformInfo(): void {
  const info = getPlatformInfo()
  console.log('[Platform Info]', {
    type: info.type,
    isNative: info.isNative,
    isWeb: info.isWeb,
    isMobile: info.isMobile,
    isDesktop: info.isDesktop,
    canUseBle: info.canUseBle,
    canUseNativeBle: info.canUseNativeBle,
    os: info.os,
    capacitorPlatform: Capacitor.getPlatform(),
    capacitorNative: Capacitor.isNativePlatform()
  })
}

export default {
  getPlatformType,
  getPlatformInfo,
  isMobile,
  isDesktop,
  canUseBle,
  canUseNativeBle,
  usePlatform,
  logPlatformInfo
}
