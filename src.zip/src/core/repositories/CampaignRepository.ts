// @ts-nocheck
/**
 * Campaign Repository - Gestion des campagnes GNSS
 * Opérations CRUD pour les campagnes avec relations et statistiques
 */

import { BaseRepository, WithSearch } from '@/core/database/repositories/BaseRepository'
import type { DatabaseCampaign, DatabaseInstallation } from '@/core/database/schema'
import type { TrackBeeDatabase } from '@/core/database/schema'
import { databaseLog } from '@/core/utils/logger'

// ==================== TYPES ====================

export interface CampaignSearchFilters {
  userId?: number
  installationId?: number
  machineId?: number
  siteId?: number
  type?: DatabaseCampaign['type'] | string
  status?: DatabaseCampaign['status'] | string
  priority?: number
  dateRange?: {
    start: Date
    end: Date
  }
  isMonitoring?: boolean
}

export interface CampaignQueryOptions {
  limit?: number
  offset?: number
  orderBy?: keyof DatabaseCampaign
  orderDirection?: 'asc' | 'desc'
  useCache?: boolean
  includeRelations?: boolean
  includeFiles?: boolean
  includeCalculations?: boolean
}

export interface CampaignWithRelations extends DatabaseCampaign {
  installationInfo?: {
    id: number
    machineId: number
    siteId: number
    machineName?: string
    siteName?: string
    siteLocation?: { lat: number; lng: number }
  }
  files?: Array<{
    id: string
    filename: string
    size: number
    path?: string
    uploadedAt?: Date
    isAvailableOffline?: boolean
  }>
  calculations?: Array<{
    id: number
    status: string
    progress?: number
    startedAt?: Date
    completedAt?: Date
    resultFiles?: string[]
  }>
  stats?: {
    totalFiles: number
    totalDataSize: number
    completedCalculations: number
    pendingCalculations: number
    duration?: number
    progress?: number
  }
}

// ==================== REPOSITORY ====================

class BaseCampaignRepository extends BaseRepository<DatabaseCampaign> {
  constructor(db: TrackBeeDatabase) {
    super(db, db.campaigns, 'campaigns', {
      enableCache: true,
      cacheTimeout: 3, // 3 minutes pour les campagnes (données plus volatiles)
      enableSync: true
    })
  }

  // ==================== QUERIES SPÉCIALISÉES ====================

  /**
   * Récupérer les campagnes par installation
   */
  async findByInstallationId(
    installationId: number,
    options: CampaignQueryOptions = {}
  ): Promise<{
    data: CampaignWithRelations[]
    total: number
    hasMore: boolean
  }> {
    const timer = databaseLog.time(`Find campaigns by installation ${installationId}`)
    const {
      limit = 50,
      offset = 0,
      orderBy = 'startedAt',
      orderDirection = 'desc',
      includeRelations = false,
      includeFiles = false,
      includeCalculations = false
    } = options

    try {
      const allCampaigns = await this.table.where('installationId').equals(installationId).toArray()
      const sorted = sortCampaignArray(allCampaigns, orderBy, orderDirection)
      const total = sorted.length
      const data = sorted.slice(offset, offset + limit)

      let enrichedData: CampaignWithRelations[] = data
      if (includeRelations || includeFiles || includeCalculations) {
        enrichedData = await this.enrichWithRelations(data, {
          includeFiles,
          includeCalculations
        })
      }

      // Mettre en cache
      if (this.options.enableCache) {
        data.forEach(campaign => this.setCacheItem(campaign.id, campaign))
      }

      timer.end({ success: true, count: data.length, total })
      databaseLog.debug(`Campaigns found for installation ${installationId}`, {
        count: data.length,
        total,
        hasMore: offset + limit < total
      })

      return {
        data: enrichedData,
        total,
        hasMore: offset + limit < total
      }

    } catch (error) {
      timer.end({ error })
      databaseLog.error(`Failed to find campaigns for installation ${installationId}`, { error })
      throw error
    }
  }

  /**
   * Récupérer les campagnes actives
   */
  async findActive(
    userId?: number,
    options: CampaignQueryOptions = {}
  ): Promise<CampaignWithRelations[]> {
    const timer = databaseLog.time('Find active campaigns')

    try {
      let query = this.table
        .where('status')
        .anyOf(['scheduled', 'running'])

      if (userId !== undefined) {
        // Joindre avec installations pour filtrer par utilisateur
        const userInstallations = await this.db.installations
          .where('userId')
          .equals(userId)
          .primaryKeys()

        query = query.and(campaign =>
          campaign.installationId != null && userInstallations.includes(campaign.installationId)
        )
      }

      const campaigns = await query
        .limit(options.limit || 50)
        .toArray()

      let enrichedData: CampaignWithRelations[] = campaigns
      if (options.includeRelations || options.includeFiles || options.includeCalculations) {
        enrichedData = await this.enrichWithRelations(campaigns, {
          includeFiles: options.includeFiles,
          includeCalculations: options.includeCalculations
        })
      }

      timer.end({ success: true, count: campaigns.length })
      databaseLog.debug(`Found ${campaigns.length} active campaigns`)

      return enrichedData

    } catch (error) {
      timer.end({ error })
      databaseLog.error('Failed to find active campaigns', { error })
      return []
    }
  }

  /**
   * Récupérer les campagnes par statut
   */
  async findByStatus(
    status: DatabaseCampaign['status'],
    userId?: number,
    options: CampaignQueryOptions = {}
  ): Promise<CampaignWithRelations[]> {
    const timer = databaseLog.time(`Find campaigns with status ${status}`)

    try {
      let query = this.table.where('status').equals(status)

      if (userId !== undefined) {
        const userInstallations = await this.db.installations
          .where('userId')
          .equals(userId)
          .primaryKeys()

        query = query.and(campaign =>
          campaign.installationId != null && userInstallations.includes(campaign.installationId)
        )
      }

      const campaigns = await query
        .limit(options.limit || 50)
        .toArray()

      let enrichedData: CampaignWithRelations[] = campaigns
      if (options.includeRelations || options.includeFiles || options.includeCalculations) {
        enrichedData = await this.enrichWithRelations(campaigns, {
          includeFiles: options.includeFiles,
          includeCalculations: options.includeCalculations
        })
      }

      timer.end({ success: true, count: campaigns.length })
      databaseLog.debug(`Found ${campaigns.length} campaigns with status ${status}`)

      return enrichedData

    } catch (error) {
      timer.end({ error })
      databaseLog.error(`Failed to find campaigns with status ${status}`, { error })
      return []
    }
  }

  /**
   * Rechercher des campagnes avec filtres avancés
   */
  async findWithFilters(
    filters: CampaignSearchFilters,
    options: CampaignQueryOptions = {}
  ): Promise<{ data: CampaignWithRelations[]; total: number }> {
    const timer = databaseLog.time('Find campaigns with filters')
    const {
      limit = 50,
      offset = 0,
      includeRelations = false,
      includeFiles = false,
      includeCalculations = false,
      orderBy,
      orderDirection
    } = options

    try {
      let filtered = await this.table.toArray()

      if (filters.installationId !== undefined) {
        filtered = filtered.filter(c => c.installationId === filters.installationId)
      }
      if (filters.type !== undefined) {
        filtered = filtered.filter(c => c.type === filters.type)
      }
      if (filters.status !== undefined) {
        filtered = filtered.filter(c => c.status === filters.status)
      }
      if (filters.priority !== undefined) {
        filtered = filtered.filter(c => c.priority === filters.priority)
      }
      if (filters.isMonitoring !== undefined) {
        filtered = filtered.filter(c => c.isMonitoring === filters.isMonitoring)
      }
      if (filters.dateRange) {
        const { start, end } = filters.dateRange
        filtered = filtered.filter(c => {
          const startedAt = c.startedAt
          return startedAt && startedAt >= start && startedAt <= end
        })
      }
      if (filters.userId !== undefined) {
        const userInstallations = await this.db.installations
          .where('userId').equals(filters.userId).primaryKeys()
        filtered = filtered.filter(c => c.installationId != null && userInstallations.includes(c.installationId))
      }

      const sorted = sortCampaignArray(filtered, orderBy, orderDirection)
      const total = sorted.length
      const limited = sorted.slice(offset, offset + limit)

      let enrichedData: CampaignWithRelations[] = limited
      if (includeRelations || includeFiles || includeCalculations) {
        enrichedData = await this.enrichWithRelations(limited, {
          includeFiles,
          includeCalculations
        })
      }

      timer.end({ success: true, count: enrichedData.length })
      databaseLog.debug('Campaigns filtered', {
        filters,
        count: enrichedData.length
      })

      return { data: enrichedData, total }

    } catch (error) {
      timer.end({ error })
      databaseLog.error('Failed to filter campaigns', { filters, error })
      throw error
    }
  }

  /**
   * Récupérer une campagne avec toutes ses relations
   */
  async findByIdWithRelations(id: number): Promise<CampaignWithRelations | null> {
    const timer = databaseLog.time(`Find campaign ${id} with relations`)

    try {
      const campaign = await this.findById(id)
      if (!campaign) return null

      const [enriched] = await this.enrichWithRelations([campaign], {
        includeFiles: true,
        includeCalculations: true
      })

      timer.end({ success: true, id })
      return enriched || null

    } catch (error) {
      timer.end({ error })
      databaseLog.error(`Failed to find campaign ${id} with relations`, { error })
      return null
    }
  }

  // ==================== OPERATIONS MÉTIER ====================

  /**
   * Démarrer une campagne
   */
  async start(id: number): Promise<boolean> {
    const timer = databaseLog.time(`Start campaign ${id}`)

    try {
      const campaign = await this.findById(id)
      if (!campaign) {
        timer.end({ error: 'Campaign not found' })
        return false
      }

      if (campaign.status !== 'scheduled') {
        timer.end({ error: `Cannot start campaign with status ${campaign.status}` })
        return false
      }

      await this.update(id, {
        status: 'running',
        startedAt: new Date(),
        isMonitoring: true
      })

      timer.end({ success: true })
      databaseLog.info(`Campaign ${id} started`)

      return true

    } catch (error) {
      timer.end({ error })
      databaseLog.error(`Failed to start campaign ${id}`, { error })
      return false
    }
  }

  /**
   * Pauser une campagne
   */
  async pause(id: number): Promise<boolean> {
    const timer = databaseLog.time(`Pause campaign ${id}`)

    try {
      const campaign = await this.findById(id)
      if (!campaign || campaign.status !== 'running') {
        timer.end({ error: 'Campaign not found or not running' })
        return false
      }

      await this.update(id, {
        status: 'paused',
        isMonitoring: false
      })

      timer.end({ success: true })
      databaseLog.info(`Campaign ${id} paused`)

      return true

    } catch (error) {
      timer.end({ error })
      databaseLog.error(`Failed to pause campaign ${id}`, { error })
      return false
    }
  }

  /**
   * Reprendre une campagne
   */
  async resume(id: number): Promise<boolean> {
    const timer = databaseLog.time(`Resume campaign ${id}`)

    try {
      const campaign = await this.findById(id)
      if (!campaign || campaign.status !== 'paused') {
        timer.end({ error: 'Campaign not found or not paused' })
        return false
      }

      await this.update(id, {
        status: 'running',
        isMonitoring: true
      })

      timer.end({ success: true })
      databaseLog.info(`Campaign ${id} resumed`)

      return true

    } catch (error) {
      timer.end({ error })
      databaseLog.error(`Failed to resume campaign ${id}`, { error })
      return false
    }
  }

  /**
   * Terminer une campagne
   */
  async complete(id: number): Promise<boolean> {
    const timer = databaseLog.time(`Complete campaign ${id}`)

    try {
      const campaign = await this.findById(id)
      if (!campaign) {
        timer.end({ error: 'Campaign not found' })
        return false
      }

      await this.update(id, {
        status: 'completed',
        completedAt: new Date(),
        isMonitoring: false
      })

      timer.end({ success: true })
      databaseLog.info(`Campaign ${id} completed`)

      return true

    } catch (error) {
      timer.end({ error })
      databaseLog.error(`Failed to complete campaign ${id}`, { error })
      return false
    }
  }

  /**
   * Annuler une campagne
   */
  async cancel(id: number, reason?: string): Promise<boolean> {
    const timer = databaseLog.time(`Cancel campaign ${id}`)

    try {
      const updateData: Partial<DatabaseCampaign> = {
        status: 'cancelled',
        isMonitoring: false
      }

      if (reason) {
        updateData.notes = reason
      }

      await this.update(id, updateData)

      timer.end({ success: true })
      databaseLog.info(`Campaign ${id} cancelled`, { reason })

      return true

    } catch (error) {
      timer.end({ error })
      databaseLog.error(`Failed to cancel campaign ${id}`, { error })
      return false
    }
  }

  /**
   * Mettre à jour le nombre de fichiers collectés
   */
  async updateFileCount(id: number, count: number): Promise<void> {
    try {
      await this.update(id, {
        filesCollected: count,
        lastFileAt: new Date()
      })

      databaseLog.debug(`Campaign ${id} file count updated`, { count })

    } catch (error) {
      databaseLog.error(`Failed to update campaign ${id} file count`, { error })
    }
  }

  // ==================== OPERATIONS BATCH ====================

  /**
   * Synchroniser les campagnes depuis le backend
   */
  async syncFromBackend(
    campaigns: Omit<DatabaseCampaign, 'createdAt' | 'updatedAt'>[]
  ): Promise<number> {
    if (!campaigns?.length) return 0

    const timer = databaseLog.time('Sync campaigns from backend')

    try {
      const count = await this.bulkUpsert(campaigns)

      timer.end({ success: true, count })
      databaseLog.info('Campaigns synced from backend', { count })
      return count

    } catch (error) {
      timer.end({ error })
      databaseLog.error('Failed to sync campaigns from backend', { error })
      throw error
    }
  }

  /**
   * Obtenir les statistiques des campagnes par utilisateur
   */
  async getStatsByUserId(userId: number): Promise<{
    total: number
    active: number
    completed: number
    scheduled: number
    running: number
    paused: number
    cancelled: number
    error: number
  }> {
    try {
      // Récupérer les installations de l'utilisateur
      const userInstallations = await this.db.installations
        .where('userId')
        .equals(userId)
        .primaryKeys()

      // Récupérer les campagnes correspondantes
      const campaigns = await this.table
        .filter(campaign => campaign.installationId != null && userInstallations.includes(campaign.installationId))
        .toArray()

      const stats = {
        total: campaigns.length,
        active: campaigns.filter(c => c.status === 'running' || c.status === 'scheduled').length,
        completed: campaigns.filter(c => c.status === 'completed').length,
        scheduled: campaigns.filter(c => c.status === 'scheduled').length,
        running: campaigns.filter(c => c.status === 'running').length,
        paused: campaigns.filter(c => c.status === 'paused').length,
        cancelled: campaigns.filter(c => c.status === 'cancelled').length,
        error: campaigns.filter(c => c.status === 'error').length
      }

      databaseLog.debug(`Campaign stats for user ${userId}`, stats)
      return stats

    } catch (error) {
      databaseLog.error(`Failed to get campaign stats for user ${userId}`, { error })
      return {
        total: 0, active: 0, completed: 0, scheduled: 0,
        running: 0, paused: 0, cancelled: 0, error: 0
      }
    }
  }

  // ==================== HELPERS PRIVÉS ====================

  /**
   * Enrichir les campagnes avec leurs relations
   */
  private async enrichWithRelations(
    campaigns: DatabaseCampaign[],
    options: {
      includeFiles?: boolean
      includeCalculations?: boolean
    } = {}
  ): Promise<CampaignWithRelations[]> {
    if (!campaigns.length) return []

    try {
      const enriched: CampaignWithRelations[] = []

      for (const campaign of campaigns) {
        const enrichedCampaign: CampaignWithRelations = { ...campaign }

        // Récupérer les infos de l'installation
        try {
          let installation: DatabaseInstallation | undefined
          if (campaign.installationId != null) {
            installation = await this.db.installations.get(campaign.installationId)
          }
          if (installation) {
            const [machine, site] = await Promise.all([
              this.db.machines.get(installation.machineId),
              this.db.sites.get(installation.siteId)
            ])

            enrichedCampaign.installationInfo = {
              id: installation.id,
              machineId: installation.machineId,
              siteId: installation.siteId,
              machineName: machine?.name,
              siteName: site?.name,
              siteLocation: (site && site.lat != null && site.lng != null)
                ? { lat: site.lat, lng: site.lng }
                : undefined
            }
          }
        } catch (error) {
          databaseLog.warn(`Failed to load installation ${campaign.installationId}`, { error })
        }

        // Récupérer les fichiers si demandé
        if (options.includeFiles) {
          try {
            const files = await this.db.files
              .where('campaignId')
              .equals(campaign.id.toString())
              .toArray()

            enrichedCampaign.files = files.map(file => ({
              id: file.id,
              filename: file.name,
              size: file.localSize || file.size || 0,
              path: file.localPath,
              uploadedAt: file.uploadedAt,
              isAvailableOffline: file.isAvailableOffline
            }))
          } catch (error) {
            databaseLog.warn(`Failed to load files for campaign ${campaign.id}`, { error })
          }
        }

        // Récupérer les calculs si demandé
        if (options.includeCalculations) {
          try {
            const calculations = await this.db.calculations
              .where('campaignId')
              .equals(campaign.id)
              .toArray()

            enrichedCampaign.calculations = calculations.map(calc => ({
              id: calc.id,
              status: calc.status,
              startedAt: calc.processingStartedAt,
              completedAt: calc.processingCompletedAt,
              resultFiles: calc.localResultFiles?.map(f => f.filename)
            }))
          } catch (error) {
            databaseLog.warn(`Failed to load calculations for campaign ${campaign.id}`, { error })
          }
        }

        // Calculer les statistiques
        const files = enrichedCampaign.files || []
        const calculations = enrichedCampaign.calculations || []

        enrichedCampaign.stats = {
          totalFiles: files.length,
          totalDataSize: files.reduce((sum, file) => sum + file.size, 0),
          completedCalculations: calculations.filter(c => c.status === 'completed' || c.status === 'done').length,
          pendingCalculations: calculations.filter(c => c.status === 'pending' || c.status === 'running' || c.status === 'queued').length,
          duration: campaign.completedAt && campaign.startedAt
            ? campaign.completedAt.getTime() - campaign.startedAt.getTime()
            : undefined,
          progress: campaign.type === 'static_simple' ? (files.length > 0 ? 100 : 0) : undefined
        }

        enriched.push(enrichedCampaign)
      }

      return enriched

    } catch (error) {
      databaseLog.error('Failed to enrich campaigns with relations', { error })
      return campaigns
    }
  }
}

function sortCampaignArray(
  campaigns: DatabaseCampaign[],
  orderBy: keyof DatabaseCampaign | undefined,
  orderDirection: 'asc' | 'desc' | undefined
): DatabaseCampaign[] {
  if (!orderBy) return [...campaigns]

  const sorted = [...campaigns].sort((a, b) => {
    const valA = a[orderBy]
    const valB = b[orderBy]

    if (valA == null && valB == null) return 0
    if (valA == null) return -1
    if (valB == null) return 1

    if (valA instanceof Date && valB instanceof Date) {
      return valA.getTime() - valB.getTime()
    }

    if (typeof valA === 'number' && typeof valB === 'number') {
      return valA - valB
    }

    return String(valA).localeCompare(String(valB))
  })

  return orderDirection === 'desc' ? sorted.reverse() : sorted
}

// ==================== REPOSITORY AVEC RECHERCHE ====================

const CampaignRepositoryBase = WithSearch<DatabaseCampaign, typeof BaseCampaignRepository>(BaseCampaignRepository)

export class CampaignRepository extends CampaignRepositoryBase {}
export type CampaignRepositoryType = CampaignRepository

// ==================== SINGLETON ====================

let campaignRepositoryInstance: CampaignRepositoryType | null = null

export function getCampaignRepository(db: TrackBeeDatabase): CampaignRepositoryType {
  if (!campaignRepositoryInstance) {
    campaignRepositoryInstance = new CampaignRepository(db)
  }
  return campaignRepositoryInstance
}

// (Types are declared and exported above.)

