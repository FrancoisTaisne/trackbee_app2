// @ts-nocheck
/**
 * Site Repository - Gestion des sites géographiques
 * Opérations CRUD pour les sites avec cache et synchronisation
 */

import { BaseRepository, WithSearch } from '@/core/database/repositories/BaseRepository'
import type { DatabaseSite } from '@/core/database/schema'
import type { TrackBeeDatabase } from '@/core/database/schema'
import { databaseLog } from '@/core/utils/logger'

// ==================== TYPES ====================

export interface SiteSearchFilters {
  userId?: number
  hasInstallations?: boolean
  isActive?: boolean
  tags?: string[]
  location?: {
    lat: number
    lng: number
    radius: number // en mètres
  }
}

export interface SiteQueryOptions {
  limit?: number
  offset?: number
  orderBy?: keyof DatabaseSite
  orderDirection?: 'asc' | 'desc'
  useCache?: boolean
  includeStats?: boolean
}

export interface SiteWithStats extends DatabaseSite {
  stats?: {
    installationCount: number
    activeInstallations: number
    lastActivity?: Date
    totalCampaigns: number
  }
}

// ==================== REPOSITORY ====================

class BaseSiteRepository extends BaseRepository<DatabaseSite> {
  constructor(db: TrackBeeDatabase) {
    super(db, db.sites, 'sites', {
      enableCache: true,
      cacheTimeout: 10, // 10 minutes pour les sites
      enableSync: true
    })
  }

  // ==================== QUERIES SPÉCIALISÉES ====================

  /**
   * Récupérer les sites par utilisateur
   */
  async findByUserId(userId: number, options: SiteQueryOptions = {}): Promise<{
    data: SiteWithStats[]
    total: number
    hasMore: boolean
  }> {
    const timer = databaseLog.time(`Find sites by user ${userId}`)
    const {
      limit = 50,
      offset = 0,
      orderBy = 'lastActivity',
      orderDirection = 'desc',
      includeStats = false
    } = options

    try {
      const all = await this.table.where('userId').equals(userId).toArray()

      const sorted = (() => {
        if (!orderBy) return all
        const arr = [...all]
        arr.sort((a, b) => {
          const va = a[orderBy]
          const vb = b[orderBy]
          if (va == null && vb == null) return 0
          if (va == null) return -1
          if (vb == null) return 1
          if (va instanceof Date && vb instanceof Date) return va.getTime() - vb.getTime()
          if (typeof va === 'number' && typeof vb === 'number') return va - vb
          return String(va).localeCompare(String(vb))
        })
        return orderDirection === 'desc' ? arr.reverse() : arr
      })()

      const total = sorted.length
      const data = sorted.slice(offset, offset + limit)

      let enrichedData: SiteWithStats[] = data
      if (includeStats) {
        enrichedData = await this.enrichWithStats(data)
      }

      // Mettre en cache
      if (this.options.enableCache) {
        data.forEach(site => this.setCacheItem(site.id, site))
      }

      timer.end({ success: true, count: data.length, total })
      databaseLog.debug(`Sites found for user ${userId}`, {
        count: data.length,
        total,
        hasMore: offset + limit < total
      })

      return {
        data: enrichedData,
        total,
        hasMore: offset + limit < total
      }

    } catch (error) {
      timer.end({ error })
      databaseLog.error(`Failed to find sites for user ${userId}`, { error })
      throw error
    }
  }

  /**
   * Rechercher des sites avec filtres avancés
   */
  async findWithFilters(
    filters: SiteSearchFilters,
    options: SiteQueryOptions = {}
  ): Promise<{ data: SiteWithStats[]; total: number }> {
    const timer = databaseLog.time('Find sites with filters')
    const { limit = 50, includeStats = false } = options

    try {
      let query = this.table.toCollection()

      // Filtrer par utilisateur
      if (filters.userId !== undefined) {
        query = query.filter(site => site.userId === filters.userId)
      }

      // Filtrer par tags
      if (filters.tags?.length) {
        query = query.filter(site =>
          filters.tags!.some(tag => site.tags?.includes(tag))
        )
      }

      // Filtrer par localisation
      if (filters.location) {
        const { lat, lng, radius } = filters.location
        query = query.filter(site => {
          if (!site.location) return false
          const distance = this.calculateDistance(
            site.location.lat,
            site.location.lng,
            lat,
            lng
          )
          return distance <= radius
        })
      }

      const data = await query.limit(limit).toArray()

      let enrichedData: SiteWithStats[] = data
      if (includeStats) {
        enrichedData = await this.enrichWithStats(data)
      }

      timer.end({ success: true, count: data.length })
      databaseLog.debug('Sites filtered', {
        filters,
        count: data.length
      })

      return { data: enrichedData, total: data.length }

    } catch (error) {
      timer.end({ error })
      databaseLog.error('Failed to filter sites', { filters, error })
      throw error
    }
  }

  /**
   * Récupérer un site avec ses statistiques
   */
  async findByIdWithStats(id: number): Promise<SiteWithStats | null> {
    const timer = databaseLog.time(`Find site ${id} with stats`)

    try {
      const site = await this.findById(id)
      if (!site) return null

      const [enriched] = await this.enrichWithStats([site])

      timer.end({ success: true, id })
      return enriched || null

    } catch (error) {
      timer.end({ error })
      databaseLog.error(`Failed to find site ${id} with stats`, { error })
      return null
    }
  }

  /**
   * Obtenir les sites favoris de l'utilisateur
   */
  async getFavorites(userId: number): Promise<DatabaseSite[]> {
    try {
      const sites = await this.table
        .where('userId')
        .equals(userId)
        .filter(site => Boolean(site.tags?.includes('favorite')))
        .toArray()

      databaseLog.debug(`Found ${sites.length} favorite sites for user ${userId}`)
      return sites

    } catch (error) {
      databaseLog.error(`Failed to get favorite sites for user ${userId}`, { error })
      return []
    }
  }

  /**
   * Marquer/Démarquer un site comme favori
   */
  async toggleFavorite(id: number): Promise<boolean> {
    try {
      const site = await this.findById(id)
      if (!site) return false

      const tags = site.tags || []
      const isFavorite = tags.includes('favorite')

      const newTags = isFavorite
        ? tags.filter(tag => tag !== 'favorite')
        : [...tags, 'favorite']

      await this.update(id, { tags: newTags })

      databaseLog.debug(`Site ${id} favorite toggled`, { isFavorite: !isFavorite })
      return !isFavorite

    } catch (error) {
      databaseLog.error(`Failed to toggle favorite for site ${id}`, { error })
      return false
    }
  }

  // ==================== OPERATIONS BATCH ====================

  /**
   * Synchroniser les sites depuis le backend
   */
  async syncFromBackend(sites: Omit<DatabaseSite, 'createdAt' | 'updatedAt'>[]): Promise<number> {
    if (!sites?.length) return 0

    const timer = databaseLog.time('Sync sites from backend')

    try {
      const count = await this.bulkUpsert(sites)

      timer.end({ success: true, count })
      databaseLog.info('Sites synced from backend', { count })
      return count

    } catch (error) {
      timer.end({ error })
      databaseLog.error('Failed to sync sites from backend', { error })
      throw error
    }
  }

  /**
   * Mettre à jour les statistiques d'activité d'un site
   */
  async updateActivity(id: number, activity: {
    lastActivity?: Date
    installationCount?: number
  }): Promise<void> {
    try {
      await this.update(id, {
        lastActivity: activity.lastActivity || new Date(),
        installationCount: activity.installationCount
      })

      databaseLog.debug(`Site ${id} activity updated`, activity)

    } catch (error) {
      databaseLog.error(`Failed to update site ${id} activity`, { error })
    }
  }

  // ==================== HELPERS PRIVÉS ====================

  /**
   * Enrichir les sites avec leurs statistiques
   */
  private async enrichWithStats(sites: DatabaseSite[]): Promise<SiteWithStats[]> {
    if (!sites.length) return []

    try {
      const enriched: SiteWithStats[] = []

      for (const site of sites) {
        // Compter les installations
        const installations = await this.db.installations
          .where('siteId')
          .equals(site.id)
          .toArray()

        const activeInstallations = installations.filter(i => i.isActive)

        // Compter les campagnes
        const campaigns = await this.db.campaigns
          .where('installationId')
          .anyOf(installations.map(i => i.id))
          .toArray()

        // Dernière activité
        const lastActivity = Math.max(
          site.lastActivity?.getTime() || 0,
          ...installations.map(i => i.lastActivity?.getTime() || 0),
          ...campaigns.map(c => c.lastFileAt?.getTime() || 0)
        )

        enriched.push({
          ...site,
          stats: {
            installationCount: installations.length,
            activeInstallations: activeInstallations.length,
            lastActivity: lastActivity > 0 ? new Date(lastActivity) : undefined,
            totalCampaigns: campaigns.length
          }
        })
      }

      return enriched

    } catch (error) {
      databaseLog.error('Failed to enrich sites with stats', { error })
      return sites
    }
  }

  /**
   * Calculer la distance entre deux points GPS
   */
  private calculateDistance(lat1: number, lng1: number, lat2: number, lng2: number): number {
    const R = 6371e3 // Rayon de la Terre en mètres
    const φ1 = lat1 * Math.PI / 180
    const φ2 = lat2 * Math.PI / 180
    const Δφ = (lat2 - lat1) * Math.PI / 180
    const Δλ = (lng2 - lng1) * Math.PI / 180

    const a = Math.sin(Δφ/2) * Math.sin(Δφ/2) +
              Math.cos(φ1) * Math.cos(φ2) *
              Math.sin(Δλ/2) * Math.sin(Δλ/2)
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a))

    return R * c
  }
}

// ==================== REPOSITORY AVEC RECHERCHE ====================

const SiteRepositoryBase = WithSearch<DatabaseSite, typeof BaseSiteRepository>(BaseSiteRepository)

export class SiteRepository extends SiteRepositoryBase {}
export type SiteRepositoryType = SiteRepository

// ==================== SINGLETON ====================

let siteRepositoryInstance: SiteRepositoryType | null = null

export function getSiteRepository(db: TrackBeeDatabase): SiteRepositoryType {
  if (!siteRepositoryInstance) {
    siteRepositoryInstance = new SiteRepository(db)
  }
  return siteRepositoryInstance
}

// (Types are declared and exported above.)

