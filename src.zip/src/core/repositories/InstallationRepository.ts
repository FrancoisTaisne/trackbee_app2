// @ts-nocheck
/**
 * Installation Repository - Gestion des installations machines/sites
 * Opérations CRUD pour les installations avec relations et cache
 */

import { BaseRepository, WithSearch } from '@/core/database/repositories/BaseRepository'
import type { DatabaseInstallation } from '@/core/database/schema'
import type { TrackBeeDatabase } from '@/core/database/schema'
import { databaseLog } from '@/core/utils/logger'

// ==================== TYPES ====================

export interface InstallationSearchFilters {
  userId?: number
  siteId?: number
  machineId?: number
  isActive?: boolean
  hasActiveCampaigns?: boolean
  dateRange?: {
    start: Date
    end: Date
  }
}

export interface InstallationQueryOptions {
  limit?: number
  offset?: number
  orderBy?: keyof DatabaseInstallation
  orderDirection?: 'asc' | 'desc'
  useCache?: boolean
  includeRelations?: boolean
  includeStats?: boolean
}

export interface InstallationWithRelations extends DatabaseInstallation {
  machineInfo?: {
    id: number
    name: string
    macAddress: string
    model?: string
    status?: string
  }
  siteInfo?: {
    id: number
    name: string
    description?: string
    location?: { lat: number; lng: number }
  }
  stats?: {
    totalCampaigns: number
    activeCampaigns: number
    completedCampaigns: number
    lastCampaignAt?: Date
    totalFiles: number
    totalDataSize: number
  }
}

// ==================== REPOSITORY ====================

class BaseInstallationRepository extends BaseRepository<DatabaseInstallation> {
  constructor(db: TrackBeeDatabase) {
    super(db, db.installations, 'installations', {
      enableCache: true,
      cacheTimeout: 5, // 5 minutes pour les installations
      enableSync: true
    })
  }

  // ==================== QUERIES SPÉCIALISÉES ====================

  /**
   * Récupérer les installations par utilisateur
   */
  async findByUserId(
    userId: number,
    options: InstallationQueryOptions = {}
  ): Promise<{
    data: InstallationWithRelations[]
    total: number
    hasMore: boolean
  }> {
    const timer = databaseLog.time(`Find installations by user ${userId}`)
    const {
      limit = 50,
      offset = 0,
      orderBy = 'lastActivity',
      orderDirection = 'desc',
      includeRelations = false,
      includeStats = false
    } = options

    try {
      const all = await this.table.where('userId').equals(userId).toArray()

      const sorted = (() => {
        if (!orderBy) return all
        const arr = [...all]
        arr.sort((a, b) => {
          const va = a[orderBy]
          const vb = b[orderBy]
          if (va == null && vb == null) return 0
          if (va == null) return -1
          if (vb == null) return 1
          if (va instanceof Date && vb instanceof Date) return va.getTime() - vb.getTime()
          if (typeof va === 'number' && typeof vb === 'number') return va - vb
          return String(va).localeCompare(String(vb))
        })
        return orderDirection === 'desc' ? arr.reverse() : arr
      })()

      const total = sorted.length
      const data = sorted.slice(offset, offset + limit)

      const shouldEnrich = includeRelations || includeStats
      const enrichedData = shouldEnrich
        ? await this.enrichWithRelations(data, { includeStats })
        : data

      // Mettre en cache
      if (this.options.enableCache) {
        data.forEach(installation => this.setCacheItem(installation.id, installation))
      }

      timer.end({ success: true, count: data.length, total })
      databaseLog.debug(`Installations found for user ${userId}`, {
        count: data.length,
        total,
        hasMore: offset + limit < total
      })

      return {
        data: enrichedData,
        total,
        hasMore: offset + limit < total
      }

    } catch (error) {
      timer.end({ error })
      databaseLog.error(`Failed to find installations for user ${userId}`, { error })
      throw error
    }
  }

  /**
   * Récupérer les installations par site
   */
  async findBySiteId(
    siteId: number,
    options: InstallationQueryOptions = {}
  ): Promise<InstallationWithRelations[]> {
    const timer = databaseLog.time(`Find installations by site ${siteId}`)

    try {
      const installations = await this.table
        .where('siteId')
        .equals(siteId)
        .limit(options.limit || 50)
        .toArray()

      const enrichedData: InstallationWithRelations[] = await this.enrichWithRelations(installations, {
        includeStats: options.includeStats
      })

      timer.end({ success: true, count: installations.length })
      databaseLog.debug(`Found ${installations.length} installations for site ${siteId}`)

      return enrichedData

    } catch (error) {
      timer.end({ error })
      databaseLog.error(`Failed to find installations for site ${siteId}`, { error })
      return []
    }
  }

  /**
   * Récupérer les installations par machine
   */
  async findByMachineId(
    machineId: number,
    options: InstallationQueryOptions = {}
  ): Promise<InstallationWithRelations[]> {
    const timer = databaseLog.time(`Find installations by machine ${machineId}`)

    try {
      const installations = await this.table
        .where('machineId')
        .equals(machineId)
        .limit(options.limit || 50)
        .toArray()

      const enrichedData: InstallationWithRelations[] = await this.enrichWithRelations(installations, {
        includeStats: options.includeStats
      })

      timer.end({ success: true, count: installations.length })
      databaseLog.debug(`Found ${installations.length} installations for machine ${machineId}`)

      return enrichedData

    } catch (error) {
      timer.end({ error })
      databaseLog.error(`Failed to find installations for machine ${machineId}`, { error })
      return []
    }
  }

  /**
   * Récupérer les installations actives
   */
  async findActive(
    userId?: number,
    options: InstallationQueryOptions = {}
  ): Promise<InstallationWithRelations[]> {
    const timer = databaseLog.time('Find active installations')

    try {
      let query = this.table.where('isActive').equals(true)

      if (userId !== undefined) {
        query = query.and(installation => installation.userId === userId)
      }

      const installations = await query
        .limit(options.limit || 50)
        .toArray()

      let enrichedData: InstallationWithRelations[] = installations
      if (options.includeRelations || options.includeStats) {
        enrichedData = await this.enrichWithRelations(installations, {
          includeStats: options.includeStats
        })
      }

      timer.end({ success: true, count: installations.length })
      databaseLog.debug(`Found ${installations.length} active installations`)

      return enrichedData

    } catch (error) {
      timer.end({ error })
      databaseLog.error('Failed to find active installations', { error })
      return []
    }
  }

  /**
   * Rechercher des installations avec filtres avancés
   */
  async findWithFilters(
    filters: InstallationSearchFilters,
    options: InstallationQueryOptions = {}
  ): Promise<{ data: InstallationWithRelations[]; total: number }> {
    const timer = databaseLog.time('Find installations with filters')
    const { limit = 50, includeRelations = false, includeStats = false } = options

    try {
      let query = this.table.toCollection()

      // Filtrer par utilisateur
      if (filters.userId !== undefined) {
        query = query.filter(installation => installation.userId === filters.userId)
      }

      // Filtrer par site
      if (filters.siteId !== undefined) {
        query = query.filter(installation => installation.siteId === filters.siteId)
      }

      // Filtrer par machine
      if (filters.machineId !== undefined) {
        query = query.filter(installation => installation.machineId === filters.machineId)
      }

      // Filtrer par statut actif
      if (filters.isActive !== undefined) {
        query = query.filter(installation => installation.isActive === filters.isActive)
      }

      // Filtrer par plage de dates
      if (filters.dateRange) {
        const { start, end } = filters.dateRange
        query = query.filter(installation => {
          const createdAt = installation.createdAt
          return createdAt && createdAt >= start && createdAt <= end
        })
      }

      const data = await query.limit(limit).toArray()
      const shouldEnrich = includeRelations || includeStats
      const enrichedData = shouldEnrich
        ? await this.enrichWithRelations(data, { includeStats })
        : data

      timer.end({ success: true, count: data.length })
      databaseLog.debug('Installations filtered', {
        filters,
        count: data.length
      })

      return { data: enrichedData, total: data.length }

    } catch (error) {
      timer.end({ error })
      databaseLog.error('Failed to filter installations', { filters, error })
      throw error
    }
  }

  /**
   * Récupérer une installation avec toutes ses relations
   */
  async findByIdWithRelations(id: number): Promise<InstallationWithRelations | null> {
    const timer = databaseLog.time(`Find installation ${id} with relations`)

    try {
      const installation = await this.findById(id)
      if (!installation) return null

      const [enriched] = await this.enrichWithRelations([installation], {
        includeStats: true
      })

      timer.end({ success: true, id })
      return enriched || null

    } catch (error) {
      timer.end({ error })
      databaseLog.error(`Failed to find installation ${id} with relations`, { error })
      return null
    }
  }

  // ==================== OPERATIONS MÉTIER ====================

  /**
   * Activer/Désactiver une installation
   */
  async toggleActive(id: number): Promise<boolean> {
    const timer = databaseLog.time(`Toggle active installation ${id}`)

    try {
      const installation = await this.findById(id)
      if (!installation) {
        timer.end({ error: 'Installation not found' })
        return false
      }

      const newStatus = !installation.isActive
      await this.update(id, {
        isActive: newStatus,
        lastActivity: new Date()
      })

      timer.end({ success: true, newStatus })
      databaseLog.info(`Installation ${id} ${newStatus ? 'activated' : 'deactivated'}`)

      return newStatus

    } catch (error) {
      timer.end({ error })
      databaseLog.error(`Failed to toggle installation ${id}`, { error })
      return false
    }
  }

  /**
   * Mettre à jour l'activité d'une installation
   */
  async updateActivity(id: number, activity?: Date): Promise<void> {
    try {
      await this.update(id, {
        lastActivity: activity || new Date()
      })

      databaseLog.debug(`Installation ${id} activity updated`)

    } catch (error) {
      databaseLog.error(`Failed to update installation ${id} activity`, { error })
    }
  }

  // ==================== OPERATIONS BATCH ====================

  /**
   * Synchroniser les installations depuis le backend
   */
  async syncFromBackend(
    installations: Omit<DatabaseInstallation, 'createdAt' | 'updatedAt'>[]
  ): Promise<number> {
    if (!installations?.length) return 0

    const timer = databaseLog.time('Sync installations from backend')

    try {
      const count = await this.bulkUpsert(installations)

      timer.end({ success: true, count })
      databaseLog.info('Installations synced from backend', { count })
      return count

    } catch (error) {
      timer.end({ error })
      databaseLog.error('Failed to sync installations from backend', { error })
      throw error
    }
  }

  /**
   * Obtenir les statistiques des installations par utilisateur
   */
  async getStatsByUserId(userId: number): Promise<{
    total: number
    active: number
    inactive: number
    withActiveCampaigns: number
  }> {
    try {
      const installations = await this.table.where('userId').equals(userId).toArray()
      const active = installations.filter(i => i.isActive)
      const inactive = installations.filter(i => !i.isActive)

      // Compter celles avec des campagnes actives
      const withActiveCampaigns = await Promise.all(
        installations.map(async installation => {
          const activeCampaigns = await this.db.campaigns
            .where('installationId')
            .equals(installation.id)
            .filter(campaign => campaign.status === 'running' || campaign.status === 'scheduled')
            .count()
          return activeCampaigns > 0
        })
      )

      const stats = {
        total: installations.length,
        active: active.length,
        inactive: inactive.length,
        withActiveCampaigns: withActiveCampaigns.filter(Boolean).length
      }

      databaseLog.debug(`Installation stats for user ${userId}`, stats)
      return stats

    } catch (error) {
      databaseLog.error(`Failed to get installation stats for user ${userId}`, { error })
      return { total: 0, active: 0, inactive: 0, withActiveCampaigns: 0 }
    }
  }

  // ==================== HELPERS PRIVÉS ====================

  /**
   * Enrichir les installations avec leurs relations
   */
  private async enrichWithRelations(
    installations: DatabaseInstallation[],
    options: { includeStats?: boolean } = {}
  ): Promise<InstallationWithRelations[]> {
    if (!installations.length) return []

    try {
      const enriched: InstallationWithRelations[] = []

      for (const installation of installations) {
        const enrichedInstallation: InstallationWithRelations = { ...installation }

        // Récupérer les infos de la machine
        try {
          const machine = await this.db.machines.get(installation.machineId)
          if (machine) {
            enrichedInstallation.machineInfo = {
              id: machine.id,
              name: machine.name,
              macAddress: machine.macAddress,
              model: machine.model,
              status: machine.lastConnectionState?.status
            }
          }
        } catch (error) {
          databaseLog.warn(`Failed to load machine ${installation.machineId}`, { error })
        }

        // Récupérer les infos du site
        try {
          const site = await this.db.sites.get(installation.siteId)
          if (site) {
            enrichedInstallation.siteInfo = {
              id: site.id,
              name: site.name,
              description: site.description,
              location: (site && site.lat != null && site.lng != null)
                ? { lat: site.lat, lng: site.lng }
                : undefined
            }
          }
        } catch (error) {
          databaseLog.warn(`Failed to load site ${installation.siteId}`, { error })
        }

        // Calculer les statistiques si demandé
        if (options.includeStats) {
          try {
            const campaigns = await this.db.campaigns
              .where('installationId')
              .equals(installation.id)
              .toArray()

            const activeCampaigns = campaigns.filter(c =>
              c.status === 'running' || c.status === 'scheduled'
            )
            const completedCampaigns = campaigns.filter(c => c.status === 'completed')

            // Récupérer les fichiers liés
            const files = await this.db.files
              .where('campaignId')
              .anyOf(campaigns.map(c => c.id.toString()))
              .toArray()

            const totalDataSize = files.reduce((sum, file) => sum + (file.localSize || 0), 0)

            const lastCampaignAt = campaigns.length > 0
              ? new Date(Math.max(...campaigns.map(c => c.lastFileAt?.getTime() || 0)))
              : undefined

            enrichedInstallation.stats = {
              totalCampaigns: campaigns.length,
              activeCampaigns: activeCampaigns.length,
              completedCampaigns: completedCampaigns.length,
              lastCampaignAt: lastCampaignAt?.getTime() ? lastCampaignAt : undefined,
              totalFiles: files.length,
              totalDataSize
            }
          } catch (error) {
            databaseLog.warn(`Failed to calculate stats for installation ${installation.id}`, { error })
          }
        }

        enriched.push(enrichedInstallation)
      }

      return enriched

    } catch (error) {
      databaseLog.error('Failed to enrich installations with relations', { error })
      return installations
    }
  }
}

// ==================== REPOSITORY AVEC RECHERCHE ====================

const InstallationRepositoryBase = WithSearch<DatabaseInstallation, typeof BaseInstallationRepository>(BaseInstallationRepository)

export class InstallationRepository extends InstallationRepositoryBase {}
export type InstallationRepositoryType = InstallationRepository

// ==================== SINGLETON ====================

let installationRepositoryInstance: InstallationRepositoryType | null = null

export function getInstallationRepository(db: TrackBeeDatabase): InstallationRepositoryType {
  if (!installationRepositoryInstance) {
    installationRepositoryInstance = new InstallationRepository(db)
  }
  return installationRepositoryInstance
}

// (Types are declared and exported above.)

