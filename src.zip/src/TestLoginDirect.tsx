/**
 * Test Login Direct - Composant de test pour diagnostiquer le problème de login
 */

import React, { useState } from 'react'
import { httpClient } from '@/core/services/api/HttpClient'
import { AuthService } from '@/core/services/api/services/AuthService'

export const TestLoginDirect: React.FC = () => {
  const [result, setResult] = useState<string>('')
  const [loading, setLoading] = useState(false)

  const credentials = {
    email: 'moderator1@test.com',
    password: 'test'
  }

  const testDirectAxios = async () => {
    setLoading(true)
    setResult('🔄 Testing direct Axios call...\n')

    try {
      const response = await httpClient.post('/api/auth/signin', credentials, {
        skipAuth: true
      })

      setResult(prev => prev + '\n✅ SUCCESS!\n' + JSON.stringify(response, null, 2))
    } catch (error) {
      setResult(prev => prev + '\n❌ ERROR: ' + (error instanceof Error ? error.message : String(error)))
    } finally {
      setLoading(false)
    }
  }

  const testAuthService = async () => {
    setLoading(true)
    setResult('🔄 Testing AuthService.login...\n')

    try {
      const response = await AuthService.login(credentials)

      setResult(prev => prev + '\n✅ SUCCESS!\n' + JSON.stringify(response, null, 2))
    } catch (error) {
      setResult(prev => prev + '\n❌ ERROR: ' + (error instanceof Error ? error.message : String(error)))
    } finally {
      setLoading(false)
    }
  }

  const testAuthStore = async () => {
    setLoading(true)
    setResult('🔄 Testing auth.store.login...\n')

    try {
      const { useAuthStore } = await import('@/core/state/stores/auth.store')
      const login = useAuthStore.getState().login

      const response = await login(credentials)

      setResult(prev => prev + '\n✅ SUCCESS!\n' + JSON.stringify(response, null, 2))
    } catch (error) {
      setResult(prev => prev + '\n❌ ERROR: ' + (error instanceof Error ? error.message : String(error)))
    } finally {
      setLoading(false)
    }
  }

  return (
    <div style={{ padding: '20px', maxWidth: '800px', margin: '0 auto', fontFamily: 'monospace' }}>
      <h1>🧪 Test Login Direct</h1>

      <div style={{ marginBottom: '20px' }}>
        <button
          onClick={testDirectAxios}
          disabled={loading}
          style={{ padding: '10px 20px', margin: '5px', fontSize: '16px' }}
        >
          Test 1: Direct HttpClient
        </button>

        <button
          onClick={testAuthService}
          disabled={loading}
          style={{ padding: '10px 20px', margin: '5px', fontSize: '16px' }}
        >
          Test 2: AuthService
        </button>

        <button
          onClick={testAuthStore}
          disabled={loading}
          style={{ padding: '10px 20px', margin: '5px', fontSize: '16px' }}
        >
          Test 3: Auth Store
        </button>

        <button
          onClick={() => setResult('')}
          style={{ padding: '10px 20px', margin: '5px', fontSize: '16px' }}
        >
          Clear
        </button>
      </div>

      <pre
        style={{
          background: '#f4f4f4',
          padding: '15px',
          borderRadius: '5px',
          whiteSpace: 'pre-wrap',
          wordWrap: 'break-word'
        }}
      >
        {result || 'Cliquez sur un bouton pour tester...'}
      </pre>
    </div>
  )
}
