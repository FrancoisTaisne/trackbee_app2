/**
 * Analyse silencieuse des données backend
 * Script intégré pour comprendre la structure des données /api/me/hydrate
 */

import { httpClient } from '@/core/services/api/HttpClient';

interface BackendAnalysis {
  status: 'success' | 'error';
  message?: string;
  user?: unknown;
  data?: unknown;
  summary?: {
    sites: number;
    machines: number;
    installations: number;
    campaigns: number;
    availableProperties: string[];
    sampleSite?: unknown;
    sampleMachine?: unknown;
  };
}

export async function analyzeBackendData(): Promise<BackendAnalysis> {
  try {
    console.log('🔍 Analyse silencieuse des données backend...');

    // Test de l'endpoint /api/me/hydrate
    const hydrateResp = await httpClient.get<any>('/api/me/hydrate');
    const hydrateData = hydrateResp.data || {};

    const summary: {
      sites: number;
      machines: number;
      installations: number;
      campaigns: number;
      availableProperties: string[];
      sampleSite?: unknown;
      sampleMachine?: unknown;
    } = {
      sites: hydrateData.sites ? hydrateData.sites.length : 0,
      machines: hydrateData.machines ? hydrateData.machines.length : 0,
      installations: hydrateData.installations ? hydrateData.installations.length : 0,
      campaigns: hydrateData.campaigns ? hydrateData.campaigns.length : 0,
      availableProperties: Object.keys(hydrateData)
    }

    const analysis: BackendAnalysis = {
      status: 'success',
      data: hydrateData,
      summary
    };

    // Échantillons de données
    if (summary.sites > 0) {
      summary.sampleSite = hydrateData.sites[0];
    }

    if (summary.machines > 0) {
      summary.sampleMachine = hydrateData.machines[0];
    }

    console.log('✅ Analyse terminée');
    console.log('📊 Résultats:', {
      sites: summary.sites,
      machines: summary.machines,
      installations: summary.installations,
      campaigns: summary.campaigns,
      propriétés: summary.availableProperties
    });

    return analysis;

  } catch (error) {
    console.error('❌ Erreur lors de l\'analyse:', error);
    return {
      status: 'error',
      message: error instanceof Error ? error.message : 'Erreur inconnue'
    };
  }
}

// Test des routes individuelles pour comparaison
export async function compareIndividualRoutes(): Promise<unknown> {
  try {
    console.log('🔍 Comparaison avec les routes individuelles...');

    const results = await Promise.allSettled([
      httpClient.get<unknown[]>('/api/site'),
      httpClient.get<unknown[]>('/api/machine/allByMod').catch(() =>
        httpClient.get<unknown[]>('/api/machine/all')
      )
    ]);

    const sitesResult = results[0];
    const machinesResult = results[1];

    const comparison = {
      hydrate_vs_individual: {
        sites: {
          individual: sitesResult.status === 'fulfilled' ? (sitesResult.value.data?.length || 0) : 0,
          individual_status: sitesResult.status
        },
        machines: {
          individual: machinesResult.status === 'fulfilled' ? (machinesResult.value.data?.length || 0) : 0,
          individual_status: machinesResult.status
        }
      }
    };

    console.log('📋 Comparaison terminée:', comparison);
    return comparison;

  } catch (error) {
    console.error('❌ Erreur lors de la comparaison:', error);
    return { error: error instanceof Error ? error.message : 'Erreur inconnue' };
  }
}

// Fonction d'analyse complète
export async function runCompleteAnalysis(): Promise<void> {
  console.log('🚀 Démarrage de l\'analyse complète backend...');

  const hydrateAnalysis = await analyzeBackendData();
  const routeComparison = await compareIndividualRoutes();

  console.log('\n🎯 RAPPORT D\'ANALYSE COMPLET:');
  console.log('=====================================');

  if (hydrateAnalysis.status === 'success' && hydrateAnalysis.summary) {
    console.log('\n💧 ENDPOINT /api/me/hydrate:');
    console.log(`   Sites: ${hydrateAnalysis.summary.sites}`);
    console.log(`   Machines: ${hydrateAnalysis.summary.machines}`);
    console.log(`   Installations: ${hydrateAnalysis.summary.installations}`);
    console.log(`   Campagnes: ${hydrateAnalysis.summary.campaigns}`);
    console.log(`   Propriétés: ${hydrateAnalysis.summary.availableProperties.join(', ')}`);

    if (hydrateAnalysis.summary.sampleSite) {
      console.log(`   Exemple de site:`, hydrateAnalysis.summary.sampleSite);
    }

    if (hydrateAnalysis.summary.sampleMachine) {
      console.log(`   Exemple de machine:`, hydrateAnalysis.summary.sampleMachine);
    }
  } else {
    console.log('\n❌ ENDPOINT /api/me/hydrate: ÉCHEC');
    console.log(`   Erreur: ${hydrateAnalysis.message}`);
  }

  console.log('\n🔗 ROUTES INDIVIDUELLES:');
  console.log('   Comparaison:', routeComparison);

  console.log('\n💡 RECOMMANDATIONS:');
  if (hydrateAnalysis.status === 'success' && hydrateAnalysis.summary) {
    const hasData = hydrateAnalysis.summary.sites > 0 || hydrateAnalysis.summary.machines > 0;

    if (hasData) {
      console.log('✅ Données trouvées - Utiliser /api/me/hydrate comme source principale');
      console.log('✅ Créer un hook useHydrate() centralisé');
      console.log('✅ Synchroniser automatiquement avec IndexedDB');
    } else {
      console.log('⚠️ Aucune donnée - Vérifier les permissions et créer des données de test');
    }
  }

  console.log('\n✅ Analyse complète terminée');
}

// Auto-exécution en mode développement
if (import.meta.env.DEV) {
  // Exposer globalement pour les tests manuels
  (window as unknown).TrackBeeBackendAnalysis = {
    analyze: analyzeBackendData,
    compare: compareIndividualRoutes,
    runComplete: runCompleteAnalysis
  };
}
